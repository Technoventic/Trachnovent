package com.m.trackapp.fragment;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.text.TextUtils;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Toast;

import com.m.trackapp.R;
import com.m.trackapp.RetrofitClasses.ApiClient;
import com.m.trackapp.RetrofitClasses.MyApiEndpointInterface;
import com.m.trackapp.Utility.AppPreferences;
import com.m.trackapp.model.ChangePasswordResponse;
import com.m.trackapp.model.HomeScreenResponse;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ChangePasswordFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    CheckBox showPasscheck;
    Button btnSave;
    EditText etOldPassword,etNewPassword,etRetypePassword;
   // private OnFragmentInteractionListener mListener;

    public ChangePasswordFragment() {
        // Required empty public constructor
    }
    public static ChangePasswordFragment newInstance() {
        ChangePasswordFragment fragment = new ChangePasswordFragment();
        return fragment;
    }
    // TODO: Rename and change types and number of parameters
    public static ChangePasswordFragment newInstance(String param1, String param2) {
        ChangePasswordFragment fragment = new ChangePasswordFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootview = inflater.inflate(R.layout.fragment_change_password, container, false);
        init(rootview);
        showPasscheck.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(!isChecked){

                    // show password
                    etOldPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                    etNewPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                    etRetypePassword.setTransformationMethod(PasswordTransformationMethod.getInstance());

                    Log.i("checker", "true");
                }

                else{
                    Log.i("checker", "false");

                    // hide password
                    etOldPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                    etNewPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                    etRetypePassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }

            }
        });
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(TextUtils.isEmpty(etOldPassword.getText().toString())){
                   // etOldPassword.setError("please fillup this field.");
                    Toast.makeText(getActivity(), "Enter Old Password", Toast.LENGTH_SHORT).show();
                }
                else  if(TextUtils.isEmpty(etNewPassword.getText().toString())){
                  //  etNewPassword.setError("please fillup this field.");
                    Toast.makeText(getActivity(), "Enter New Password", Toast.LENGTH_SHORT).show();
                }
                else if(TextUtils.isEmpty(etRetypePassword.getText().toString())){
                   // etRetypePassword.setError("please fillup this field.");
                    Toast.makeText(getActivity(), "Enter Retype Password", Toast.LENGTH_SHORT).show();
                }
                else  if(!etNewPassword.getText().toString().equals(etRetypePassword.getText().toString())){
                    Toast.makeText(getActivity(), "Password not matched", Toast.LENGTH_SHORT).show();
                }
                else {
                    changePasswordApi();
                }

                }
        });

        return rootview;
    }

    private void changePasswordApi() {
      String oldPassword =  etOldPassword.getText().toString();
       String newPassword = etNewPassword.getText().toString();
        MyApiEndpointInterface apiService = ApiClient.getClient().create(MyApiEndpointInterface.class);

        Call<ChangePasswordResponse> call = apiService.change_password("change_password",AppPreferences.getStrUserId("userid"),oldPassword,newPassword);//userid from appprefrence
        call.enqueue(new Callback<ChangePasswordResponse>() {
            @Override
            public void onResponse(Call<ChangePasswordResponse> call, Response<ChangePasswordResponse> response) {

                ChangePasswordResponse changePasswordRes = response.body();
                Log.d("PASWWORD",changePasswordRes.getStatus());
                if(changePasswordRes.getStatus().equalsIgnoreCase("200")){
                    Toast.makeText(getActivity(), "Password Changed successfully", Toast.LENGTH_SHORT).show();
                    closefragment();

                }
                else {
                    Toast.makeText(getActivity(), "Some Error Occured", Toast.LENGTH_SHORT).show();
                }
/*
                else if(changePasswordRes.getStatus().equalsIgnoreCase("400")){
                    Toast.makeText(getActivity(), "Some Error Occured", Toast.LENGTH_SHORT).show();
                }
*/
                //Log.d("FFF",aboutUsResult.toString());


            }

            @Override
            public void onFailure(Call<ChangePasswordResponse> call, Throwable t) {
                Log.d("SSSSS33",t.toString());
            }
        });

    }

    private void closefragment() {
        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.frame_layout, ItemFiveFragment.newInstance());
        transaction.addToBackStack(null);
        transaction.commit();
    }

    private void init(View rootview) {
        showPasscheck =  (CheckBox) rootview.findViewById(R.id.checkShowPassword);
        etOldPassword =  (EditText) rootview.findViewById(R.id.etOldPassword);
        etNewPassword =  (EditText) rootview.findViewById(R.id.etNewPassword);
        etRetypePassword =  (EditText) rootview.findViewById(R.id.etRetypePassword);
        btnSave =  (Button) rootview.findViewById(R.id.btnSave);
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
       /* if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }*/
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
       /* if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }*/
    }

    @Override
    public void onDetach() {
        super.onDetach();
       // mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
/*
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
*/
}
