package com.m.trackapp.fragment;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.m.trackapp.Activity.DashboardActivity;
import com.m.trackapp.R;
import com.m.trackapp.RetrofitClasses.ApiClient;
import com.m.trackapp.RetrofitClasses.MyApiEndpointInterface;
import com.m.trackapp.model.AboutUsResult;
import com.m.trackapp.model.DashboardResponse;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AboutUsFragment extends Fragment {
    TextView tvcontent;
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

  //  private OnFragmentInteractionListener mListener;

    public AboutUsFragment() {
        // Required empty public constructor
    }
    public static AboutUsFragment newInstance() {
        AboutUsFragment fragment = new AboutUsFragment();
        return fragment;
    }


    // TODO: Rename and change types and number of parameters
    public static AboutUsFragment newInstance(String param1, String param2) {
        AboutUsFragment fragment = new AboutUsFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
/*
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
*/
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootview = inflater.inflate(R.layout.fragment_about_us, container, false);
        init(rootview);
        getAbout_us();

       // tvcontent.setText("");
        return rootview;
    }

    private void getAbout_us() {
        MyApiEndpointInterface apiService = ApiClient.getClient().create(MyApiEndpointInterface.class);

        Call<AboutUsResult> call = apiService.about_us_data("about_us","1");//userid from appprefrence
        call.enqueue(new Callback<AboutUsResult>() {
            @Override
            public void onResponse(Call<AboutUsResult> call, Response<AboutUsResult> response) {

               // AboutUsResult aboutUsResult = response.body();
                //Log.d("FFF",aboutUsResult.toString());

                try {
                    AboutUsResult aboutUsResult = response.body();
                   // DashboardResponse dashboardResponse = response.body();

                    if(aboutUsResult.getStatus().equalsIgnoreCase("200")){

                        tvcontent.setText(aboutUsResult.getResult());

                    }
                    else if(aboutUsResult.getStatus().equalsIgnoreCase("400")){
                        Toast.makeText(getActivity(),aboutUsResult.getMessage(), Toast.LENGTH_SHORT).show();
                    }






                } catch (Exception e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Call<AboutUsResult> call, Throwable t) {
                Log.d("SSSSS33",t.toString());
            }
        });
    }

    private void init(View rootview) {
        tvcontent = (TextView)rootview.findViewById(R.id.tvcontent);

    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
/*
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
*/
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
      /*  if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }*/
    }

    @Override
    public void onDetach() {
        super.onDetach();
      //  mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
/*
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
*/
}
