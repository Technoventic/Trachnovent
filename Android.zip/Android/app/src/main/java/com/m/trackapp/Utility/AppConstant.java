package com.m.trackapp.Utility;



public class AppConstant {

    public interface BASEURL {



       // String URL = "http://49.50.118.216/api/v1/";
        String URL = "http://track.tracknovate.com/api/v1/";
        //http://49.50.118.216/api/v1/CombinedHomeScreen.php
      //  http://49.50.118.216/api/v1/Settings.php
       // http://49.50.118.216/api/v1/HomeScreen.php
        //http://49.50.118.216/api/v1/OrganizationInfo.php
       // http://49.50.118.216/api/v1/login.php
        //http://49.50.118.216/api/v1/ForgetPassword.php
        //http://49.50.118.216/api/v1/UserDashboard.php
      //  http://49.50.118.216/api/v1/Logout.php
      //  http://track.tracknovate.com/api/v1/HelpAndSupport.php
     //   http://49.50.118.216/api/v1/Notification.php
     //   http://track.tracknovate.com/api/v1/Playback.php
    }

    public interface ENDPOINT {

        String FIRSTPAGE = "login.php";
        String FORGOTPASSWORD = "ForgetPassword.php";
        String DASHBOARD = "UserDashboard.php";
        String ABOUTUS = "OrganizationInfo.php";
        String HOMESCREEN = "HomeScreen.php";
        String CHANGEPASSWORD = "Settings.php";
        String ALLTRUCKDETAILS = "CombinedHomeScreen.php";
        String LOGOUT = "Logout.php";
        String HELP_SUPPORT = "HelpAndSupport.php";
        String USER_DASHBOARD_NEW = "UserDashboardNew.php";
        String NOTIFICATION = "Notification.php";
        String PLAYBACK_MAP = "Playback.php ";



    }
}


