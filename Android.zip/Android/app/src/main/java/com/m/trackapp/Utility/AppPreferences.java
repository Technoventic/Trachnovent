package com.m.trackapp.Utility;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;


public class AppPreferences {
    private static Context context;

    public AppPreferences(Context context){
        this.context = context;
    }

    public final static String PREFS_NAME = "appname_prefs";

/*
    public static void setInt( String key, int value) {
        SharedPreferences sharedPref = context.getSharedPreferences(PREFS_NAME,0);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putInt(key, value);
        editor.apply();
    }
*/

/*
    public static int getInt(String key) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, 0);
        return prefs.getInt(key, 0);
    }
*/

    public static void setStrUserId(String key, String value) {
        SharedPreferences sharedPref = context.getSharedPreferences(PREFS_NAME,0);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putString(key, value);
        editor.apply();
    }

    public static String getStrUserId(String key) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, 0);
        return prefs.getString(key,"DNF");
    }

    public static void setMapType(String key, String value) {
        SharedPreferences sharedPref1 = context.getSharedPreferences(PREFS_NAME,0);
        SharedPreferences.Editor editor1 = sharedPref1.edit();
        editor1.putString(key, value);
        editor1.apply();
    }
    public static String getMapType(String key) {
        SharedPreferences prefs1 = context.getSharedPreferences(PREFS_NAME, 0);
        return prefs1.getString(key,"DNF");
    }

    public static void clearPrefrence(Context context) {
        SharedPreferences preferences = context.getSharedPreferences(PREFS_NAME, 0);
        preferences.edit().clear().commit();


    }


/*
    public static void setBool(String key, boolean value) {
        SharedPreferences sharedPref = context.getSharedPreferences(PREFS_NAME,0);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putBoolean(key, value);
        editor.apply();
    }
*/

/*
    public static boolean getBool(String key) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, 0);
        return prefs.getBoolean(key,false);
    }
*/
   /*public static final String TRACKAPP = "track_app";
   public static final String KEY = "your_key";






   private final SharedPreferences sharedPreferences;
   private final Editor editor;
   public static String getStringPref(Context context) {
       SharedPreferences pereference = context.getSharedPreferences(
               KEY, 0);
       return pereference.getString(TRACKAPP, "");
   }

   public static void setStringPref(Context context, String text) {
       SharedPreferences preferences = context.getSharedPreferences(
               KEY, 0);
       Editor editor = preferences.edit();
       editor.putString(TRACKAPP, text);
       editor.commit();
   }
    public static String getStringPrefuserid(Context context) {
        SharedPreferences pereference = context.getSharedPreferences(
                KEY, 0);
        return pereference.getString(TRACKAPP, "");
    }

    public static void setStringPrefuserid(Context context, String userid) {
        SharedPreferences preferences = context.getSharedPreferences(
                KEY, 0);
        Editor editor = preferences.edit();
        editor.putString(TRACKAPP, userid);
        editor.commit();
    }
    public static String getStringPrefuserpw(Context context) {
        SharedPreferences pereference = context.getSharedPreferences(
                KEY, 0);
        return pereference.getString(TRACKAPP, "");
    }

    public static void setStringPrefuserpw(Context context, String password) {
        SharedPreferences preferences = context.getSharedPreferences(
                KEY, 0);
        Editor editor = preferences.edit();
        editor.putString(TRACKAPP, password);
        editor.commit();
    }
    public static boolean getStringPrefboolean(Context context) {
        SharedPreferences pereference = context.getSharedPreferences(
                KEY, 0);
        return pereference.getBoolean(TRACKAPP, false);
    }

    public static void setStringPrefboolean(Context context, boolean isremember) {
        SharedPreferences preferences = context.getSharedPreferences(
                KEY, 0);
        Editor editor = preferences.edit();
        editor.putBoolean(TRACKAPP, isremember);
        editor.commit();
    }


    public static void clearPrefreces(Context context){
      *//* SharedPreferences sharedPrefs = context.getSharedPreferences(
               KEY, 0);
       Editor editor = sharedPrefs.edit();
       editor.clear();
       editor.commit();*//*
   }


   public AppPreferences(Context context) {
       String prefsFile = context.getPackageName();
       sharedPreferences = context.getSharedPreferences(prefsFile, Context.MODE_PRIVATE);
       editor = sharedPreferences.edit();
   }

*/
}
