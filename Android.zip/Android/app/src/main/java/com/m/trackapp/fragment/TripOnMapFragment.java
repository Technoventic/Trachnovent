package com.m.trackapp.fragment;

import android.content.Context;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.github.mikephil.charting.animation.Easing;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.listener.OnChartValueSelectedListener;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import com.m.trackapp.R;
import com.m.trackapp.Utility.FontAwesome;

import java.util.ArrayList;
import java.util.List;

public class TripOnMapFragment extends Fragment implements OnChartValueSelectedListener, OnMapReadyCallback {
    PieChart pieChart;
    View rootview;
    private GoogleMap mMap;
    MapView mapView;
    FontAwesome btnRefresh,btnsetting;
    LinearLayout linearSetting,linearDate;
    ArrayList<Entry> yvalues = new ArrayList<Entry>();
    FontAwesome tvDownArrow;

    private static final LatLng LOWER_MANHATTAN = new LatLng(22.7244,
            75.8839);
    private static final LatLng TIMES_SQUARE = new LatLng(18.58078, 73.903191);
    private static final LatLng BROOKLYN_BRIDGE = new LatLng(22.623642, 75.65776);
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    //private OnFragmentInteractionListener mListener;

    public TripOnMapFragment() {
        // Required empty public constructor
    }

    // TODO: Rename and change types and number of parameters
/*
    public static TripOnMapFragment newInstance(String param1, String param2) {
        TripOnMapFragment fragment = new TripOnMapFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }
*/
    public static TripOnMapFragment newInstance() {
        TripOnMapFragment fragment = new TripOnMapFragment();
        return fragment;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
         rootview = inflater.inflate(R.layout.fragment_trip_on_map, container, false);
        linearSetting =  (LinearLayout)rootview.findViewById(R.id.linearSetting);
        tvDownArrow =  (FontAwesome)rootview.findViewById(R.id.tvDownArrow);
        linearDate =  (LinearLayout)rootview.findViewById(R.id.linearDate);

        btnRefresh = (FontAwesome)rootview.findViewById(R.id.btnRefresh);
        btnsetting = (FontAwesome)rootview.findViewById(R.id.btnsetting);
        pieChart = (PieChart)rootview.findViewById(R.id.piechart);
        pieChart.setUsePercentValues(false);
        pieChart.setOnChartValueSelectedListener(this);

        Display display = getActivity().getWindowManager().getDefaultDisplay();
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getActivity().getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
     int height =   displayMetrics.heightPixels;
          int offset = (int)(height * 0.9);
        RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams)pieChart.getLayoutParams();
        params.setMargins(0,0,0,-offset);
        pieChart.setLayoutParams(params);

       /* pieChart.getLayoutParams().height = 1000 / 6;
        pieChart.getLayoutParams().width = 1000;*/
       // pieChart.setCenterText(" Total\n"+ "4");
        pieChart.setCenterTextSize(12f);
        yvalues.add(new Entry(1, 0));
        yvalues.add(new Entry(1, 1));
        yvalues.add(new Entry(1, 2));
        yvalues.add(new Entry(1, 3));
        yvalues.add(new Entry(1, 4));
        PieDataSet dataSet = new PieDataSet(yvalues, "Results");
        ArrayList<String> xVals = new ArrayList<String>();
        dataSet.setDrawValues(false);
        xVals.add("1X");
        xVals.add("2X");
        xVals.add("3X");
        xVals.add("4X");
        xVals.add("5X");
       // xVals.add("6X");
        //xVals.add("June");

        PieData data = new PieData(xVals, dataSet);
        // In Percentage term
        // data.setValueFormatter(new PercentFormatter());
        dataSet.setSliceSpace(0.5f);
        // Default value
        //data.setValueFormatter(new DefaultValueFormatter(0));
        pieChart.setData(data);
        pieChart.setDescription("");
        //   pieChart.setCenterText(" Total\n"+0);
        //   pieChart.setCenterText("Total:"\n + 0);
        pieChart.invalidate();
        pieChart.setDrawHoleEnabled(true);
        pieChart.getLegend().setEnabled(false);
        pieChart.setHoleColor(getResources().getColor(R.color.dashboard_middlecircle));

        pieChart.setTouchEnabled(true);
        pieChart.setRotationEnabled(false);
        pieChart.setMaxAngle(180f);
        pieChart.setRotationAngle(180f);




        pieChart.setTransparentCircleRadius(60f);
        pieChart.setDrawSlicesUnderHole(true);
        pieChart.setHoleRadius(55f); //total

        // dataSet.setColors(ColorTemplate.VORDIPLOM_COLORS);
        // PieDataSet dataSet = new PieDataSet(entries, "Fuel");

        dataSet.setColors(new int[] {R.color.themecolor, R.color.themecolor, R.color.themecolor, R.color.themecolor,R.color.themecolor }, getActivity());
        data.setValueTextSize(12f);
        data.setValueTextColor(Color.WHITE);


       // pieChart.animateXY(1400, 1400);
        pieChart.animateY(1000,Easing.EasingOption.EaseInCubic);

        btnRefresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentManager mFragmentManager = ((FragmentActivity) getContext()).getSupportFragmentManager();
                FragmentTransaction ft = mFragmentManager.beginTransaction();
                ft.addToBackStack(null);
                ft.replace(R.id.frame_layout, TripOnMapFragment.newInstance());
                ft.commit();
            }
        });

        btnsetting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                linearSetting.setVisibility(View.VISIBLE);
                //Toast.makeText(getActivity(), "Work in process", Toast.LENGTH_SHORT).show();
            }
        });
        tvDownArrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                linearSetting.setVisibility(View.GONE);
            }
        });

        linearDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        return rootview;
    }
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mapView = (MapView) rootview.findViewById(R.id.mapview);
        if (mapView != null) {
            mapView.onCreate(null);
            mapView.onResume();
            mapView.getMapAsync(this);
        }
    }


    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
/*
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
*/
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
/*        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }*/
    }

    @Override
    public void onDetach() {
        super.onDetach();
        //mListener = null;
    }

    @Override
    public void onValueSelected(Entry e, int dataSetIndex, Highlight h) {
        /*List<Integer> colors = pieChart.getData().getDataSetByIndex(dataSetIndex).getColors();

        int newcolor = Color.WHITE;
        colors.set(e.getXIndex(), newcolor); // replace the color at the specified index
        pieChart.invalidate(); // refresh*/
    }

    @Override
    public void onNothingSelected() {

    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        MapsInitializer.initialize(getContext());
        mMap = googleMap;
        mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);

        googleMap
                .addPolyline((new PolylineOptions())
                        .add(TIMES_SQUARE, BROOKLYN_BRIDGE, LOWER_MANHATTAN,
                                TIMES_SQUARE).width(5).color(Color.BLUE)
                        .geodesic(true));
        // move camera to zoom on map
        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(LOWER_MANHATTAN,
                13));


    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
/*
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
*/
}
