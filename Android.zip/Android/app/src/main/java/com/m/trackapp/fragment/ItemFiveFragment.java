package com.m.trackapp.fragment;

import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SwitchCompat;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.Toast;

import com.m.trackapp.Activity.DashboardActivity;
import com.m.trackapp.Activity.LoginActivity;
import com.m.trackapp.R;
import com.m.trackapp.RetrofitClasses.ApiClient;
import com.m.trackapp.RetrofitClasses.MyApiEndpointInterface;
import com.m.trackapp.Utility.AppPreferences;
import com.m.trackapp.Utility.FontAwesome;
import com.m.trackapp.model.ChangePasswordResponse;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.m.trackapp.Activity.DashboardActivity.PREFS_NAME;


public class ItemFiveFragment extends Fragment {
    RecyclerView mRecyclerView;
    FontAwesome changepw,notification,about_us,mapbtn,geofancingbtn,helpbtn,refreshbtn,logoutbtn;

    public static ItemFiveFragment newInstance() {
        ItemFiveFragment fragment = new ItemFiveFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootview = inflater.inflate(R.layout.fragment_item_five, container, false);
        DrawerLayout navDrawer = rootview.findViewById(R.id.drawer_layout);
        // If navigation drawer is not open yet open it else close it.
        if(!navDrawer.isDrawerOpen(GravityCompat.END)) navDrawer.openDrawer(Gravity.END);
        else navDrawer.closeDrawer(Gravity.START);

        changepw = (FontAwesome)rootview.findViewById(R.id.changepassword);
        notification = (FontAwesome)rootview.findViewById(R.id.notification);
        about_us = (FontAwesome)rootview.findViewById(R.id.about_us);
        mapbtn = (FontAwesome)rootview.findViewById(R.id.mapbtn);
        geofancingbtn = (FontAwesome)rootview.findViewById(R.id.geofancingbtn);
        helpbtn = (FontAwesome)rootview.findViewById(R.id.helpbtn);
        refreshbtn = (FontAwesome)rootview.findViewById(R.id.refreshbtn);
        logoutbtn = (FontAwesome)rootview.findViewById(R.id.logoutbtn);


        changepw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.frame_layout, ChangePasswordFragment.newInstance());
                transaction.addToBackStack(null);
                transaction.commit();
            }
        });

        notification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              //  notification.setBackgroundDrawable(getResources().getDrawable(R.drawable.selected_settingcircle));
                FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.frame_layout, NotificationFragment.newInstance());
                transaction.addToBackStack(null);
                transaction.commit();
            }
        });
        about_us.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.frame_layout, AboutUsFragment.newInstance());
                transaction.addToBackStack(null);
                transaction.commit();
            }
        });

        mapbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.frame_layout, MapFragment.newInstance());
                transaction.addToBackStack(null);
                transaction.commit();
            }
        });
        helpbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.frame_layout, HelpFragment.newInstance());
                transaction.addToBackStack(null);
                transaction.commit();
            }
        });
        logoutbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                logoutDialog();
            }
        });
        geofancingbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.frame_layout, GeoFancingFragment.newInstance());
                transaction.addToBackStack(null);
                transaction.commit();
              //  geoFancingDialog();
            }
        });

        refreshbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.frame_layout, RefreshTimeFragment.newInstance());
                transaction.addToBackStack(null);
                transaction.commit();
            }
        });

       /* mRecyclerView = rootview.findViewById(R.id.left_drawer);
        GridLayoutManager mGridLayoutManager = new GridLayoutManager(getActivity(), 2);
        mRecyclerView.setLayoutManager(mGridLayoutManager);


        SettingAdapter myAdapter = new SettingAdapter(getActivity());
        mRecyclerView.setAdapter(myAdapter);*/



        return rootview;
    }

/*
    private void geoFancingDialog() {
        final Dialog dialog = new Dialog(getActivity());
        dialog.setCancelable(true);

        dialog.setContentView(R.layout.geofancingdialog);
        ImageView delete = (ImageView)dialog.findViewById(R.id.btnCancel);
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Do something
                dialog.dismiss();
            }
        });

        dialog.show();
    }
*/

    private void logoutDialog(){

        final Dialog dialog = new Dialog(getActivity());
        dialog.setCancelable(true);

        dialog.setContentView(R.layout.logout_dialog);
        ImageView delete = (ImageView)dialog.findViewById(R.id.btnCancel);
        SwitchCompat switchCompat = (SwitchCompat) dialog.findViewById(R.id.switch_compat);
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Do something
              dialog.dismiss();
            }
        });
        switchCompat.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
              if(buttonView.getId() == R.id.switch_compat){
                 // Log.i("switch_compat", isChecked + "");
                  if(isChecked == true){
                      userLogout();

                     // startActivity(new Intent(getActivity(),LoginActivity.class));
                  }
                  else {
                      dialog.dismiss();
                  }
              }
            }
        });
        dialog.show();
/*
        switchCompat.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {}
               */
/* switch (buttonView.getId()) {
                    case R.id.switch_compat:
                        Log.i("switch_compat", isChecked + "");
                        break;*//*

*/
/*case R.id.switch_compat2:
                        Log.i("switch_compat2", isChecked + "");
                        break;*//*
*/
/*

                }
            }
        });
*//*


       */
/* TextView edit = (TextView) getView().findViewById(R.id.edit);
        TextView delete = (TextView) getView().findViewById(R.id.btnCancel);*//*



      */
/*  edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Do something

            }
        });
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Do something

            }
        });*//*




        dialog.show();
    }
*/
}

    private void userLogout() {
        MyApiEndpointInterface apiService = ApiClient.getClient().create(MyApiEndpointInterface.class);

        Call<ChangePasswordResponse> call = apiService.user_logout(AppPreferences.getStrUserId("userid"));//userid from appprefrence
        call.enqueue(new Callback<ChangePasswordResponse>() {
            @Override
            public void onResponse(Call<ChangePasswordResponse> call, Response<ChangePasswordResponse> response) {

                ChangePasswordResponse changePasswordRes = response.body();
                Log.d("LOGOUTTT",changePasswordRes.getStatus());
                if(changePasswordRes.getStatus().equalsIgnoreCase("200")){
                    SharedPreferences settings = getActivity().getSharedPreferences(PREFS_NAME, 0);
                    SharedPreferences.Editor editor = settings.edit();
                    settings.getBoolean("hasLoggedIn", false); // getting boolean
                    editor.clear();
                    editor.commit();


                    AppPreferences.clearPrefrence(getActivity());
                    Intent intent = new Intent(getActivity(), LoginActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    getActivity().finish();
                    Toast.makeText(getActivity(), "Logout successfully", Toast.LENGTH_SHORT).show();


                }
                else {
                    Toast.makeText(getActivity(), "Some Error Occured", Toast.LENGTH_SHORT).show();
                }
/*
                else if(changePasswordRes.getStatus().equalsIgnoreCase("400")){
                    Toast.makeText(getActivity(), "Some Error Occured", Toast.LENGTH_SHORT).show();
                }
*/
                //Log.d("FFF",aboutUsResult.toString());


            }

            @Override
            public void onFailure(Call<ChangePasswordResponse> call, Throwable t) {
                Log.d("SSSSS33",t.toString());
            }
        });


    }
}