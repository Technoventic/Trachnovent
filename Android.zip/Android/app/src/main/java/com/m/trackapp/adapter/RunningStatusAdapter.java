package com.m.trackapp.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.m.trackapp.R;



public class RunningStatusAdapter  extends RecyclerView.Adapter<RunningStatusAdapter.ViewHolder  > {

    Context context;
    RunningStatusAdapter.OnItemClick itemClick;




    public RunningStatusAdapter(Context context,RunningStatusAdapter.OnItemClick itemClick){
        this.context = context;
        this.itemClick = itemClick;



    }

    @Override
    public RunningStatusAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.runningstatusview, parent, false);
        RunningStatusAdapter.ViewHolder viewHolder = new RunningStatusAdapter.ViewHolder(v);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(final RunningStatusAdapter.ViewHolder holder, int position) {
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                itemClick.itemClick();
            }
        });
    }

    @Override
    public int getItemCount() {
        return 10 ;
    }
    public class ViewHolder extends RecyclerView.ViewHolder  {
        //TextView textview;

        //  CustomTextView order_id,order_amount,order_time,order_status;
        View view;

        public ViewHolder(View itemView) {
            super(itemView);
            view=itemView;

           // textview =(TextView)view.findViewById(R.id.textview);


        }

    }

    public  interface OnItemClick{
        void itemClick();
    }


}