package com.m.trackapp.fragment;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.CardView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.m.trackapp.R;

public class YesterdayFragment extends Fragment implements View.OnClickListener {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

  //  private OnFragmentInteractionListener mListener;

    public YesterdayFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment YesterdayFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static YesterdayFragment newInstance(String param1, String param2) {
        YesterdayFragment fragment = new YesterdayFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootview = inflater.inflate(R.layout.fragment_today, container, false);
        init(rootview);
        return rootview;
    }

    private void init(View rootview) {
        ((CardView)rootview.findViewById(R.id.runningCard)).setOnClickListener(this);
        ((CardView)rootview.findViewById(R.id.idleCard)).setOnClickListener(this);
        ((CardView)rootview.findViewById(R.id.stopCard)).setOnClickListener(this);
        ((CardView)rootview.findViewById(R.id.nodataCard)).setOnClickListener(this);
        ((CardView)rootview.findViewById(R.id.totalCard)).setOnClickListener(this);
        ((CardView)rootview.findViewById(R.id.offlineCard)).setOnClickListener(this);
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
/*
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
*/
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
       /* if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }*/
    }

    @Override
    public void onDetach() {
        super.onDetach();
       // mListener = null;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.runningCard:

                Bundle bundle = new Bundle();
                bundle.putString("TRUCKSTATUS", "Running");
                RunningStatusFragment fragInfo = new RunningStatusFragment();
                fragInfo.setArguments(bundle);
                FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.frame_layout, fragInfo);
                transaction.addToBackStack(null);
                transaction.commit();

                break;

            case R.id.idleCard:

                Bundle bundle1 = new Bundle();
                bundle1.putString("TRUCKSTATUS", "Idle");
                RunningStatusFragment fragInfo1 = new RunningStatusFragment();
                fragInfo1.setArguments(bundle1);
                FragmentTransaction transaction1 = getActivity().getSupportFragmentManager().beginTransaction();
                transaction1.replace(R.id.frame_layout, fragInfo1);
                transaction1.addToBackStack(null);
                transaction1.commit();

                break;

            case R.id.stopCard:
                Bundle bundle2 = new Bundle();
                bundle2.putString("TRUCKSTATUS", "Stop");
                RunningStatusFragment fragInfo2 = new RunningStatusFragment();
                fragInfo2.setArguments(bundle2);
                FragmentTransaction transaction2 = getActivity().getSupportFragmentManager().beginTransaction();
                transaction2.replace(R.id.frame_layout, fragInfo2);
                transaction2.addToBackStack(null);
                transaction2.commit();

                break;

            case R.id.totalCard:
                Bundle bundle3 = new Bundle();
                bundle3.putString("TRUCKSTATUS", "Total");
                RunningStatusFragment fragInfo3 = new RunningStatusFragment();
                fragInfo3.setArguments(bundle3);
                FragmentTransaction transaction3 = getActivity().getSupportFragmentManager().beginTransaction();
                transaction3.replace(R.id.frame_layout, fragInfo3);
                transaction3.addToBackStack(null);
                transaction3.commit();

                break;

            case R.id.offlineCard:
                Bundle bundle4 = new Bundle();
                bundle4.putString("TRUCKSTATUS", "Offline");
                RunningStatusFragment fragInfo4 = new RunningStatusFragment();
                fragInfo4.setArguments(bundle4);
                FragmentTransaction transaction4 = getActivity().getSupportFragmentManager().beginTransaction();
                transaction4.replace(R.id.frame_layout, fragInfo4);
                transaction4.addToBackStack(null);
                transaction4.commit();

                break;

            case R.id.nodataCard:

                Bundle bundle5 = new Bundle();
                bundle5.putString("TRUCKSTATUS", "Nodata");
                RunningStatusFragment fragInfo5 = new RunningStatusFragment();
                fragInfo5.setArguments(bundle5);
                FragmentTransaction transaction5 = getActivity().getSupportFragmentManager().beginTransaction();
                transaction5.replace(R.id.frame_layout, fragInfo5);
                transaction5.addToBackStack(null);
                transaction5.commit();
                break;

        }

    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
/*
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
*/
}
