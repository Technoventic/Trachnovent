package com.m.trackapp.fragment;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.m.trackapp.R;
import com.m.trackapp.RetrofitClasses.ApiClient;
import com.m.trackapp.RetrofitClasses.MyApiEndpointInterface;
import com.m.trackapp.Utility.AppPreferences;
import com.m.trackapp.adapter.AllTruckDetailAdapter;
import com.m.trackapp.model.AllTruckResponse;
import com.m.trackapp.model.AllTruckdetailResult;
import com.m.trackapp.model.ChangePasswordResponse;
import com.m.trackapp.model.Imei;
import com.m.trackapp.model.Imei____;
import com.m.trackapp.model.Imei_____;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AllTruckFragment extends Fragment {
    AllTruckDetailAdapter detailAdapter;
    RecyclerView recyclerView;
    List<Imei_____> truckdetailResults = new ArrayList<Imei_____>();
    ProgressBar progressBar;
    TextView tvNoText;
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER


  //  private OnFragmentInteractionListener mListener;

    public AllTruckFragment() {
        // Required empty public constructor
    }
    public static AllTruckFragment newInstance() {
        AllTruckFragment fragment = new AllTruckFragment();
        return fragment;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       /* if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }*/
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootview = inflater.inflate(R.layout.fragment_all_truck, container, false);
        progressBar = (ProgressBar) rootview.findViewById(R.id.progress_bar);

        recyclerView = (RecyclerView) rootview.findViewById(R.id.recycler_view);
        tvNoText = (TextView) rootview.findViewById(R.id.tvNoText);
        getAllTruckDetail();

        /*detailAdapter = new AllTruckDetailAdapter(getActivity());
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(detailAdapter);*/
        return rootview;
    }

/*
    private void getAllTruckDetail() {

        MyApiEndpointInterface apiService = ApiClient.getClient().create(MyApiEndpointInterface.class);
        Call<AllTruckResponse> call = apiService.all_truck_details_list("1");//userid from appprefrence
        call.enqueue(new Callback<AllTruckResponse>() {
            @Override
            public void onResponse(Call<AllTruckResponse> call, Response<AllTruckResponse> response) {
                if(response.isSuccessful()){
                    Log.d("CODEPFRES",response.code()+"");
                }
                else if (response.errorBody() != null) {
                    // Get response errorBody
                    try {
                        String errorBody = response.errorBody().string();
                        Log.d("ERRORtttttt",errorBody);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(Call<AllTruckResponse> call, Throwable t) {

                t.printStackTrace();
            }
        });
    }
*/

    private void getAllTruckDetail() {
        progressBar.setVisibility(View.VISIBLE);
        MyApiEndpointInterface apiService = ApiClient.getClient().create(MyApiEndpointInterface.class);

        Call<AllTruckResponse> call = apiService.all_truck_details_list(AppPreferences.getStrUserId("userid"));//userid from appprefrence
        call.enqueue(new Callback<AllTruckResponse>() {
            @Override
            public void onResponse(Call<AllTruckResponse> call, Response<AllTruckResponse> response) {
                AllTruckResponse allTruckResponse = response.body();

                for(int i = 0;i< allTruckResponse.getResult().size();i++){
                    if(allTruckResponse.getResult().get(i).getTotal().get(i).getImei().size()>0){
                        Log.d("ALLTRUCK",allTruckResponse.getResult().get(i).getTotal().get(i).getImei().size()+"");
                        truckdetailResults = allTruckResponse.getResult().get(i).getTotal().get(i).getImei();
                    }
                    else {
                        tvNoText.setVisibility(View.VISIBLE);
                        Toast.makeText(getActivity(), "NO ALL DATA", Toast.LENGTH_SHORT).show();
                    }

                }
                detailAdapter = new AllTruckDetailAdapter(getActivity(),truckdetailResults, new AllTruckDetailAdapter.OnItemClick() {
                    @Override
                    public void itemClick(Imei_____ imeimoidal) {
                        Log.d("DATAANOTHER",imeimoidal.getName());
                        /*FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
                        transaction.replace(R.id.frame_layout, ItemOneFragment.newInstance());
                        transaction.addToBackStack(null);
                        transaction.commit();*/

                        Bundle bundle = new Bundle();
                       // String myMessage = "Stackoverflow is cool!";
                        bundle.putSerializable("MODALL", imeimoidal);
                        ItemOneFragment fragInfo = new ItemOneFragment();
                        fragInfo.setArguments(bundle);
                        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
                        transaction.replace(R.id.frame_layout, fragInfo);
                        transaction.addToBackStack(null);
                        transaction.commit();


                    }
                });
                RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
                recyclerView.setLayoutManager(mLayoutManager);
                recyclerView.setItemAnimator(new DefaultItemAnimator());
                recyclerView.setAdapter(detailAdapter);
                detailAdapter.notifyDataSetChanged();
                progressBar.setVisibility(View.GONE);

                }

            @Override
            public void onFailure(Call<AllTruckResponse> call, Throwable t) {
                Log.d("SSSSS33",t.toString());
                progressBar.setVisibility(View.GONE);
                //Toast.makeText(getActivity(), "Server Error", Toast.LENGTH_SHORT).show();
            }
        });

    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
       /* if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }*/
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
       /* if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }*/
    }

    @Override
    public void onDetach() {
        super.onDetach();
      //  mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
/*
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
*/
}
