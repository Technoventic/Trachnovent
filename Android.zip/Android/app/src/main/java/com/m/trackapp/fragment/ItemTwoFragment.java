package com.m.trackapp.fragment;



import android.content.Context;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;

import com.m.trackapp.R;

import java.util.ArrayList;
import java.util.List;

public class ItemTwoFragment extends Fragment {
    public static ItemTwoFragment newInstance() {
        ItemTwoFragment fragment = new ItemTwoFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootview = inflater.inflate(R.layout.fragment_item_two, container, false);
        Toolbar toolbar = (Toolbar) rootview.findViewById(R.id.toolbar);

        //for crate home button
        AppCompatActivity activity = (AppCompatActivity) getActivity();
        activity.setSupportActionBar(toolbar);
       // activity.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setTablayout(rootview);
        return rootview;
    }

    private void setTablayout(View rootview) {
        ViewPager viewPager = (ViewPager) rootview.findViewById(R.id.viewpager);
        ItemTwoFragment.PagerAdapter pagerAdapter = new PagerAdapter(getActivity().getSupportFragmentManager(), getActivity());
        pagerAdapter.addFragment(new TodayFragment());
        pagerAdapter.addFragment(new YesterdayFragment());
        pagerAdapter.addFragment(new WeekFragment());
        pagerAdapter.addFragment(new MonthFragment());
        pagerAdapter.addFragment(new CustomFragment());

        viewPager.setAdapter(pagerAdapter);
        TabLayout tabLayout = (TabLayout) rootview.findViewById(R.id.tab_layout);
        tabLayout.setupWithViewPager(viewPager);
        tabLayout.getTabAt(0).setText("Today");
        tabLayout.getTabAt(1).setText("Yesterday");
        tabLayout.getTabAt(2).setText("Week");
        tabLayout.getTabAt(3).setText("Month");
        tabLayout.getTabAt(4).setText("Custom");


        viewPager.setCurrentItem(0);
    }
    class PagerAdapter extends android.support.v4.app.FragmentStatePagerAdapter {
        Context context;
        List<Fragment> managerList = new ArrayList<Fragment>();

        public PagerAdapter(FragmentManager fm, Context context) {
            super(fm);
            this.context = context;
        }

        @Override
        public int getCount() {
            return managerList.size();
        }   //size

        public void addFragment(Fragment fragment) {
            managerList.add(fragment);
        }

        @Override
        public Fragment getItem(int position) {
            return managerList.get(position);
        }
/*
        @Override
        public CharSequence getPageTitle(int position) {
            return "aaa"+position;
        }*/
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.custom_drawer, menu);
        super.onCreateOptionsMenu(menu,inflater);
    }}