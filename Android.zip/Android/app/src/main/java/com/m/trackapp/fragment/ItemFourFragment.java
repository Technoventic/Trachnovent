package com.m.trackapp.fragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.m.trackapp.R;

public class ItemFourFragment extends Fragment {
    LinearLayout linearStopage;

    public static ItemFourFragment newInstance() {
        ItemFourFragment fragment = new ItemFourFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootview = inflater.inflate(R.layout.fragment_item_four, container, false);
        DrawerLayout navDrawer = rootview.findViewById(R.id.drawer_layout);
        // If navigation drawer is not open yet open it else close it.
        if(!navDrawer.isDrawerOpen(GravityCompat.END)) navDrawer.openDrawer(Gravity.END);
        else navDrawer.closeDrawer(Gravity.START);

        linearStopage =   (LinearLayout)rootview.findViewById(R.id.stopageReport);
        linearStopage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.frame_layout, StopageReportFragment.newInstance());
                transaction.addToBackStack(null);
                transaction.commit();
            }
        });

        return rootview;
    }
}