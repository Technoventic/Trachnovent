package com.m.trackapp.Activity;


import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.m.trackapp.R;
import com.m.trackapp.RetrofitClasses.ApiClient;
import com.m.trackapp.RetrofitClasses.MyApiEndpointInterface;

import com.m.trackapp.Utility.AppPreferences;
import com.m.trackapp.model.ForgotPasswordResponse;



import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ForgotPassword extends AppCompatActivity {
    EditText etEmailid;
    Button btnSubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);
      etEmailid =  (EditText)findViewById(R.id.etEmailid);
      btnSubmit =  (Button)findViewById(R.id.btnSubmit);
      btnSubmit.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {
            String emailid =  etEmailid.getText().toString().trim();
              if(emailid.equals("")){
                  Toast.makeText(getApplicationContext(), "Email ID Missing", Toast.LENGTH_SHORT).show();
              }
              else {
                  getForgotPassword();
              }
          }
      });


    }

    private void getForgotPassword() {
        MyApiEndpointInterface apiService = ApiClient.getClient().create(MyApiEndpointInterface.class);

        Call<ForgotPasswordResponse> call = apiService.getForgotPassword(etEmailid.getText().toString().trim(),AppPreferences.getStrUserId("userid"));//userid from appprefrence
        call.enqueue(new Callback<ForgotPasswordResponse>() {
            @Override
            public void onResponse(Call<ForgotPasswordResponse> call, Response<ForgotPasswordResponse> response) {

                try {

                    ForgotPasswordResponse forgotPasswordResponse = response.body();

                    if(forgotPasswordResponse.getStatus().equalsIgnoreCase("200")){
                        Toast.makeText(ForgotPassword.this, forgotPasswordResponse.getResult().getMsg(), Toast.LENGTH_SHORT).show();
                        etEmailid.setText("");
                        finish();
                    }
                    else if(forgotPasswordResponse.getStatus().equalsIgnoreCase("400")){
                        Toast.makeText(ForgotPassword.this,forgotPasswordResponse.getResult().getMsg(), Toast.LENGTH_SHORT).show();
                    }

                      





                } catch (Exception e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Call<ForgotPasswordResponse> call, Throwable t) {
                Log.d("SSSSS33",t.toString());
            }
        });
    }
}
