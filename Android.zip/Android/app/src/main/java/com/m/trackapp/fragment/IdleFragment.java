package com.m.trackapp.fragment;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.m.trackapp.R;
import com.m.trackapp.RetrofitClasses.ApiClient;
import com.m.trackapp.RetrofitClasses.MyApiEndpointInterface;
import com.m.trackapp.Utility.AppPreferences;
import com.m.trackapp.adapter.IdleTruckDetailAdapter;
import com.m.trackapp.adapter.RunningTruckDetailAdapter;
import com.m.trackapp.model.AllTruckResponse;
import com.m.trackapp.model.Imei;
import com.m.trackapp.model.Imei__;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class IdleFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    IdleTruckDetailAdapter idleTruckDetailAdapter;
    RecyclerView recyclerView;
    List<Imei__> truckdetailResults = new ArrayList<Imei__>();
    ProgressBar progressBar;
    TextView tvNoText;

    //private OnFragmentInteractionListener mListener;

    public IdleFragment() {
        // Required empty public constructor
    }
    public static IdleFragment newInstance() {
        IdleFragment fragment = new IdleFragment();
        return fragment;
    }


    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment IdleFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static IdleFragment newInstance(String param1, String param2) {
        IdleFragment fragment = new IdleFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootview = inflater.inflate(R.layout.fragment_idle, container, false);
        recyclerView = (RecyclerView) rootview.findViewById(R.id.recycler_view);
        progressBar = (ProgressBar) rootview.findViewById(R.id.progress_bar);
        tvNoText = (TextView) rootview.findViewById(R.id.tvNoText);
        getIdleTruckDetail();

       /* idleTruckDetailAdapter = new IdleTruckDetailAdapter(getActivity());
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(idleTruckDetailAdapter);*/
        return rootview;
    }

    private void getIdleTruckDetail() {
        progressBar.setVisibility(View.VISIBLE);
        MyApiEndpointInterface apiService = ApiClient.getClient().create(MyApiEndpointInterface.class);

        Call<AllTruckResponse> call = apiService.all_truck_details_list(AppPreferences.getStrUserId("userid"));//userid from appprefrence
        call.enqueue(new Callback<AllTruckResponse>() {
            @Override
            public void onResponse(Call<AllTruckResponse> call, Response<AllTruckResponse> response) {
                AllTruckResponse allTruckResponse = response.body();

                for(int i = 0;i< allTruckResponse.getResult().size();i++){
                    if(allTruckResponse.getResult().get(i).getIdle().get(i).getImei().size()>0){
                        Log.d("IDLETRUCK",allTruckResponse.getResult().get(i).getIdle().get(i).getImei().size()+"");
                        truckdetailResults = allTruckResponse.getResult().get(i).getIdle().get(i).getImei();
                    }
                    else {
                        tvNoText.setVisibility(View.VISIBLE);
//                        Toast.makeText(getActivity(), "NO IDLE DATA", Toast.LENGTH_SHORT).show();
                    }

                }
                idleTruckDetailAdapter = new IdleTruckDetailAdapter(getActivity(),truckdetailResults, new IdleTruckDetailAdapter.OnItemClick() {
                    @Override
                    public void itemClick(Imei__ imeimoidal) {

                        Log.d("IDLEANOTHER",imeimoidal.getName());
                        Bundle bundle = new Bundle();
                        // String myMessage = "Stackoverflow is cool!";
                        bundle.putSerializable("MODALLIDLE", imeimoidal);
                        ItemOneFragment fragInfo = new ItemOneFragment();
                        fragInfo.setArguments(bundle);
                        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
                        transaction.replace(R.id.frame_layout, fragInfo);
                        transaction.addToBackStack(null);
                        transaction.commit();

                      /*  FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
                        transaction.replace(R.id.frame_layout, ItemOneFragment.newInstance());
                        transaction.addToBackStack(null);
                        transaction.commit();*/




                    }
                });
                RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
                recyclerView.setLayoutManager(mLayoutManager);
                recyclerView.setItemAnimator(new DefaultItemAnimator());
                recyclerView.setAdapter(idleTruckDetailAdapter);
                idleTruckDetailAdapter.notifyDataSetChanged();
                progressBar.setVisibility(View.GONE);

            }

            @Override
            public void onFailure(Call<AllTruckResponse> call, Throwable t) {
                Log.d("SSSSS33",t.toString());
                progressBar.setVisibility(View.GONE);
                Toast.makeText(getActivity(), "Server Error", Toast.LENGTH_SHORT).show();
            }
        });
    }


    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
       /* if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }*/
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
      /*  if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }*/
    }

    @Override
    public void onDetach() {
        super.onDetach();
        // mListener = null;
    }

   /* public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }*/
}
