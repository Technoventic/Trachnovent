package com.m.trackapp.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class AllTruckdetailResult {
    @SerializedName("running")
    @Expose
    private List<Running> running = null;
    @SerializedName("stop")
    @Expose
    private List<Stop> stop = null;
    @SerializedName("idle")
    @Expose
    private List<Idle> idle = null;
    @SerializedName("no_data")
    @Expose
    private List<NoDatum> noData = null;
    @SerializedName("offline")
    @Expose
    private List<Offline> offline = null;
    @SerializedName("total")
    @Expose
    private List<Total> total = null;

    public List<Running> getRunning() {
        return running;
    }

    public void setRunning(List<Running> running) {
        this.running = running;
    }

    public List<Stop> getStop() {
        return stop;
    }

    public void setStop(List<Stop> stop) {
        this.stop = stop;
    }

    public List<Idle> getIdle() {
        return idle;
    }

    public void setIdle(List<Idle> idle) {
        this.idle = idle;
    }

    @Override
    public String toString() {
        return "AllTruckdetailResult{" +
                "running=" + running +
                ", stop=" + stop +
                ", idle=" + idle +
                ", noData=" + noData +
                ", offline=" + offline +
                ", total=" + total +
                '}';
    }

    public List<NoDatum> getNoData() {
        return noData;
    }

    public void setNoData(List<NoDatum> noData) {
        this.noData = noData;
    }

    public List<Offline> getOffline() {
        return offline;
    }

    public void setOffline(List<Offline> offline) {
        this.offline = offline;
    }

    public List<Total> getTotal() {
        return total;
    }

    public void setTotal(List<Total> total) {
        this.total = total;
    }

}
