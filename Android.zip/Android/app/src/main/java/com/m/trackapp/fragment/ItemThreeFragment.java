package com.m.trackapp.fragment;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.formatter.PercentFormatter;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.listener.OnChartValueSelectedListener;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.m.trackapp.Activity.LoginActivity;
import com.m.trackapp.Activity.TruckDetailActivity;
import com.m.trackapp.R;
import com.m.trackapp.RetrofitClasses.ApiClient;
import com.m.trackapp.RetrofitClasses.MyApiEndpointInterface;
import com.m.trackapp.Utility.AppPreferences;
import com.m.trackapp.model.DashboardNewResponse;
import com.m.trackapp.model.DashboardNewResult;
import com.m.trackapp.model.DashboardResponse;

import java.util.ArrayList;


import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ItemThreeFragment extends Fragment implements OnChartValueSelectedListener {
    PieChart pieChart;
    ArrayList<Entry> yvalues = new ArrayList<Entry>();
    ArrayList<DashboardNewResponse> dataObjects  = new ArrayList<DashboardNewResponse>();


    public static ItemThreeFragment newInstance() {
        ItemThreeFragment fragment = new ItemThreeFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View myFragmentView = inflater.inflate(R.layout.fragment_item_three, container, false);
         pieChart = (PieChart)myFragmentView.findViewById(R.id.piechart);
         getDashboardData();

        pieChart.setUsePercentValues(false);
        pieChart.setOnChartValueSelectedListener(this);

        // IMPORTANT: In a PieChart, no values (Entry) should have the same
        // xIndex (even if from different DataSets), since no values can be
/*
        for (DashboardResponse data : dataObjects) {

            // turn your data into Entry objects
            yvalues.add(new Entry(Float.parseFloat(String.valueOf(data.getResult().getIdle())), 0));
            yvalues.add(new Entry(Float.parseFloat(String.valueOf(data.getResult().getIdle())), 1));
            yvalues.add(new Entry(Float.parseFloat(String.valueOf(data.getResult().getIdle())), 2));
            yvalues.add(new Entry(Float.parseFloat(String.valueOf(data.getResult().getIdle())), 3));
            yvalues.add(new Entry(Float.parseFloat(String.valueOf(data.getResult().getIdle())), 4));
        }
*/
        // drawn above each other.
       /* yvalues.add(new Entry(20f, 0));
        yvalues.add(new Entry(20f, 1));
        yvalues.add(new Entry(20f, 2));
        yvalues.add(new Entry(20f, 3));
        yvalues.add(new Entry(20f, 4));*/
        //  yvalues.add(new Entry(17f, 5));

      //  PieDataSet dataSet = new PieDataSet(yvalues, "Results");


       /* ArrayList<String> xVals = new ArrayList<String>();

        xVals.add("Stop");
        xVals.add("Running");
        xVals.add("No data");
        xVals.add("Inactive");
        xVals.add("Idle");
        //xVals.add("June");

        PieData data = new PieData(xVals, dataSet);
        // In Percentage term
        data.setValueFormatter(new PercentFormatter());
        dataSet.setSliceSpace(10f);
        // Default value
        //data.setValueFormatter(new DefaultValueFormatter(0));
        pieChart.setData(data);
        pieChart.setDescription("");
        pieChart.setCenterText(" Total\n"+0);
     //   pieChart.setCenterText("Total:"\n + 0);
        pieChart.invalidate();
        pieChart.setDrawHoleEnabled(true);
        pieChart.getLegend().setEnabled(false);
        pieChart.setHoleColor(getResources().getColor(R.color.dashboard_middlecircle));


        pieChart.setDrawHoleEnabled(true);
        pieChart.setTransparentCircleRadius(50f);
        pieChart.setHoleRadius(25f);

       // dataSet.setColors(ColorTemplate.VORDIPLOM_COLORS);
       // PieDataSet dataSet = new PieDataSet(entries, "Fuel");

        dataSet.setColors(new int[] {R.color.dashboard_slicered, R.color.dashboard_slicegreen, R.color.dashboard_slicegray, R.color.dashboard_sliceblue,R.color.dashboard_sliceyellow }, getActivity());
        data.setValueTextSize(13f);
        data.setValueTextColor(Color.DKGRAY);
        pieChart.setOnChartValueSelectedListener(this);

        pieChart.animateXY(1400, 1400);
*/
        return myFragmentView;
    }

    private void getDashboardData() {
        Log.d("USERID",AppPreferences.getStrUserId("userid"));
        MyApiEndpointInterface apiService = ApiClient.getClient().create(MyApiEndpointInterface.class);

        Call<DashboardNewResponse> call = apiService.user_dashboard_new(AppPreferences.getStrUserId("userid"));//userid from appprefrence
        call.enqueue(new Callback<DashboardNewResponse>() {
            @Override
            public void onResponse(Call<DashboardNewResponse> call, Response<DashboardNewResponse> response) {

                try {

                    DashboardNewResponse dashboardResponse = response.body();

                    if(dashboardResponse.getStatus().equalsIgnoreCase("200")){
                        dataObjects.add(dashboardResponse);

                        for (DashboardNewResponse newResponse : dataObjects) {

                            // turn your data into Entry objects
                            Log.d("XXX",newResponse.getResult().getStop());
                          /*  yvalues.add(new Entry(data.getResult().getStop(), 0));
                            yvalues.add(new Entry(data.getResult().getRunning(), 1));
                            yvalues.add(new Entry(data.getResult().getNoData(), 2));
                            yvalues.add(new Entry(data.getResult().getOffline(), 3));
                            yvalues.add(new Entry(data.getResult().getIdle(), 4));*/
                           // yvalues.add(new Entry(8f, 5));
                           // pieChart.setCenterText(" Total\n"+ newResponse.getResult().getTotal());
                            pieChart.setCenterText(newResponse.getResult().getTotal());
                            pieChart.setCenterTextSize(16f);

                            yvalues.add(new Entry(1, 0));
                            yvalues.add(new Entry(1, 1));
                            yvalues.add(new Entry(1, 2));
                            yvalues.add(new Entry(1, 3));
                            yvalues.add(new Entry(1, 4));
                            PieDataSet dataSet = new PieDataSet(yvalues, "Results");
                            ArrayList<String> xVals = new ArrayList<String>();
                            dataSet.setDrawValues(false);
                            xVals.add(newResponse.getResult().getStop());
                            xVals.add(newResponse.getResult().getRunning());
                            xVals.add(newResponse.getResult().getNoData());
                            xVals.add(newResponse.getResult().getOffline());
                            xVals.add(newResponse.getResult().getIdle());
                            //xVals.add("June");

                            PieData data = new PieData(xVals, dataSet);
                            // In Percentage term
                            // data.setValueFormatter(new PercentFormatter());
                            dataSet.setSliceSpace(0f);
                            // Default value
                            //data.setValueFormatter(new DefaultValueFormatter(0));
                            pieChart.setData(data);
                            pieChart.setDescription("");
                            //   pieChart.setCenterText(" Total\n"+0);
                            //   pieChart.setCenterText("Total:"\n + 0);
                            pieChart.invalidate();
                            pieChart.setDrawHoleEnabled(true);
                            pieChart.getLegend().setEnabled(false);
                            pieChart.setHoleColor(getResources().getColor(R.color.dashboard_middlecircle));



                            pieChart.setTransparentCircleRadius(30f);
                            pieChart.setHoleRadius(25f); //total

                            // dataSet.setColors(ColorTemplate.VORDIPLOM_COLORS);
                            // PieDataSet dataSet = new PieDataSet(entries, "Fuel");

                            dataSet.setColors(new int[] {R.color.redcolor, R.color.greencolor, R.color.gray_color, R.color.bluecolor,R.color.yellowcolor }, getActivity());
                            data.setValueTextSize(16f);
                            data.setValueTextColor(Color.WHITE);


                            pieChart.animateXY(1400, 1400);

                        }


                        //  yvalues.add(new Entry(17f, 5))
/*
                        for (DashboardResponse data : dataObjects) {

                            // turn your data into Entry objects
                            yvalues.add(new Entry(1f, 0));
                            yvalues.add(new Entry(2f, 1));
                            yvalues.add(new Entry(5f, 2));
                            yvalues.add(new Entry(6f, 3));
                            yvalues.add(new Entry(8f, 4));
                            yvalues.add(new Entry(8f, 5));
                        }
*/

                        //   ArrayList<Entry> stringList = new ArrayList<Entry>();

                        /*yvalues.add(new Entry(Float.parseFloat(dashboardResponse.getResult().getRunning(), 0));
                        yvalues.add(new Entry(dashboardResponse.getResult().getStop(), 1));
                        yvalues.add(new Entry(dashboardResponse.getResult().getIdle(), 2));
                        yvalues.add(new Entry(dashboardResponse.getResult().getNoData(), 3));
                        yvalues.add(new Entry(dashboardResponse.getResult().getTotal(), 4));*/

                      /*  stringList.add(new Entry(dashboardResponse.getResult().getRunning()));

                        stringList.add(String.valueOf(dashboardResponse.getResult().getStop()));
                        stringList.add(String.valueOf(dashboardResponse.getResult().getIdle()));
                        stringList.add(String.valueOf(dashboardResponse.getResult().getNoData()));
                        stringList.add(String.valueOf(dashboardResponse.getResult().getTotal()));*/

                    }
                    else if(dashboardResponse.getStatus().equalsIgnoreCase("400")){


                        Toast.makeText(getActivity(),dashboardResponse.getMessage(), Toast.LENGTH_SHORT).show();
                    }







                } catch (Exception e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Call<DashboardNewResponse> call, Throwable t) {
                Log.d("SSSSS33",t.toString());
            }
        });
    }

    @Override
    public void onValueSelected(Entry e, int dataSetIndex, Highlight h) {

        if (e == null)
            return;

        Log.i("VAL SELECTED",
                "Value: " + e.getVal() + ", xIndex: " + e.getXIndex()
                        + ", DataSet index: " + dataSetIndex);


       // AppPreferences.setStringPref(getActivity(),e.getXIndex()+"");

        pieChart.highlightValues(null);
        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.frame_layout, TruckDetailFragment.newInstance());
        transaction.addToBackStack(null);
        transaction.commit();

       /* Intent intent = new Intent(getActivity().getApplication(),TruckDetailActivity.class);
        startActivity(intent);*/
    }

    @Override
    public void onNothingSelected() {
        Log.i("PieChart", "nothing selected");

    }


}