package com.m.trackapp.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class DashboardNewResult {

    @SerializedName("running")
    @Expose
    private String running;
    @SerializedName("stop")
    @Expose
    private String stop;
    @SerializedName("idle")
    @Expose
    private String idle;
    @SerializedName("no_data")
    @Expose
    private String noData;
    @SerializedName("offline")
    @Expose
    private String offline;
    @SerializedName("total")
    @Expose
    private String total;

    public String getRunning() {
        return running;
    }

    public void setRunning(String running) {
        this.running = running;
    }

    public String getStop() {
        return stop;
    }

    public void setStop(String stop) {
        this.stop = stop;
    }

    public String getIdle() {
        return idle;
    }

    public void setIdle(String idle) {
        this.idle = idle;
    }

    public String getNoData() {
        return noData;
    }

    public void setNoData(String noData) {
        this.noData = noData;
    }

    public String getOffline() {
        return offline;
    }

    public void setOffline(String offline) {
        this.offline = offline;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

}
