package com.m.trackapp.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class Imei___ implements Serializable {


    @SerializedName("imei")
    @Expose
    private String imei;
    @SerializedName("lattitude")
    @Expose
    private String lattitude;
    @SerializedName("longitude")
    @Expose
    private String longitude;
    @SerializedName("date_server")
    @Expose
    private String dateServer;
    @SerializedName("angle")
    @Expose
    private String angle;
    @SerializedName("speed")
    @Expose
    private String speed;
    @SerializedName("ignition")
    @Expose
    private String ignition;
    @SerializedName("battery")
    @Expose
    private String battery;
    @SerializedName("batteryLevel")
    @Expose
    private String batteryLevel;
    @SerializedName("distance")
    @Expose
    private String distance;
    @SerializedName("totalDistance")
    @Expose
    private String totalDistance;
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("sim_number")
    @Expose
    private String simNumber;
    @SerializedName("model")
    @Expose
    private String model;
    @SerializedName("status")
    @Expose
    private String status;
    @SerializedName("min_moving_speed")
    @Expose
    private String minMovingSpeed;

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    @SerializedName("min_idle_speed")
    @Expose

    private String minIdleSpeed;
    @SerializedName("min_fuel_speed")
    @Expose
    private String minFuelSpeed;
    @SerializedName("img")
    @Expose
    private String img;

    @SerializedName("img_top")
    @Expose
    private String img_top;

    @SerializedName("ac")
    @Expose
    private String ac;

    @SerializedName("fuel")
    @Expose
    private String fuel;

    @SerializedName("duration")
    @Expose
    private String duration;


    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public String getLattitude() {
        return lattitude;
    }

    public void setLattitude(String lattitude) {
        this.lattitude = lattitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getDateServer() {
        return dateServer;
    }

    public void setDateServer(String dateServer) {
        this.dateServer = dateServer;
    }

    public String getAngle() {
        return angle;
    }

    public void setAngle(String angle) {
        this.angle = angle;
    }

    public String getSpeed() {
        return speed;
    }

    public void setSpeed(String speed) {
        this.speed = speed;
    }

    public String getIgnition() {
        return ignition;
    }

    public void setIgnition(String ignition) {
        this.ignition = ignition;
    }

    public String getBattery() {
        return battery;
    }

    public void setBattery(String battery) {
        this.battery = battery;
    }

    public String getBatteryLevel() {
        return batteryLevel;
    }

    public void setBatteryLevel(String batteryLevel) {
        this.batteryLevel = batteryLevel;
    }

    public String getDistance() {
        return distance;
    }

    public void setDistance(String distance) {
        this.distance = distance;
    }

    public String getTotalDistance() {
        return totalDistance;
    }

    public void setTotalDistance(String totalDistance) {
        this.totalDistance = totalDistance;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSimNumber() {
        return simNumber;
    }

    public void setSimNumber(String simNumber) {
        this.simNumber = simNumber;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMinMovingSpeed() {
        return minMovingSpeed;
    }

    public void setMinMovingSpeed(String minMovingSpeed) {
        this.minMovingSpeed = minMovingSpeed;
    }

    public String getMinIdleSpeed() {
        return minIdleSpeed;
    }

    public void setMinIdleSpeed(String minIdleSpeed) {
        this.minIdleSpeed = minIdleSpeed;
    }

    public String getMinFuelSpeed() {
        return minFuelSpeed;
    }

    public void setMinFuelSpeed(String minFuelSpeed) {
        this.minFuelSpeed = minFuelSpeed;
    }

    public String getImg_top() {
        return img_top;
    }

    public void setImg_top(String img_top) {
        this.img_top = img_top;
    }

    public String getAc() {
        return ac;
    }

    public void setAc(String ac) {
        this.ac = ac;
    }

    public String getFuel() {
        return fuel;
    }

    public void setFuel(String fuel) {
        this.fuel = fuel;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }
}
