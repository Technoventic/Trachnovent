package com.m.trackapp.fragment;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.m.trackapp.Activity.DashboardActivity;
import com.m.trackapp.R;
import com.m.trackapp.RetrofitClasses.ApiClient;
import com.m.trackapp.RetrofitClasses.MyApiEndpointInterface;
import com.m.trackapp.Utility.AppPreferences;
import com.m.trackapp.model.DashboardResponse;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class TruckDetailFragment extends Fragment implements View.OnClickListener {
  RecyclerView  mRecycler;
    //TextView txtCount,txtCount1,txtCount2,txtCount3,txtCount4,txtCount5;
    Button textView1,textView2,textView3,textView4,textView5,textView6;
    TextView tv1,tv2,tv3,tv4,tv5,tv6;





   // private OnFragmentInteractionListener mListener;

    public TruckDetailFragment() {
        // Required empty public constructor
    }


    public static TruckDetailFragment newInstance() {
        TruckDetailFragment fragment = new TruckDetailFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View roorview = inflater.inflate(R.layout.fragment_truck_detail, container, false);
        init(roorview);

        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.framelayout, AllTruckFragment.newInstance());
        transaction.commit();

      //  setTablayout(roorview);
        getDashboardData(roorview);

        roorview.setFocusableInTouchMode(true);
        roorview.requestFocus();
        roorview.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {

                if( keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_UP) {
                    FragmentManager mFragmentManager = ((FragmentActivity) getContext()).getSupportFragmentManager();
                    FragmentTransaction ft = mFragmentManager.beginTransaction();
                    ft.addToBackStack(null);
                    ft.add(R.id.frame_layout, ItemThreeFragment.newInstance());
                    ft.commit();
                    return true;
                }
                return false;
            }
        });
        return roorview;
    }

    private void init(View rootview) {
        ((Button) rootview.findViewById(R.id.text1)).setOnClickListener(this);
        ((Button) rootview.findViewById(R.id.text2)).setOnClickListener(this);
        ((Button) rootview.findViewById(R.id.text3)).setOnClickListener(this);
        ((Button) rootview.findViewById(R.id.text4)).setOnClickListener(this);
        ((Button) rootview.findViewById(R.id.text5)).setOnClickListener(this);
        ((Button) rootview.findViewById(R.id.text6)).setOnClickListener(this);

        textView1 =  (Button)rootview.findViewById(R.id.text1);
        textView2 =  (Button)rootview.findViewById(R.id.text2);
        textView3 =  (Button)rootview.findViewById(R.id.text3);
        textView4 =  (Button)rootview.findViewById(R.id.text4);
        textView5 =  (Button)rootview.findViewById(R.id.text5);
        textView6 =  (Button)rootview.findViewById(R.id.text6);

        tv1 = (TextView) rootview.findViewById(R.id.tv1);
        tv2 = (TextView) rootview.findViewById(R.id.tv2);
        tv3 = (TextView) rootview.findViewById(R.id.tv3);
        tv4 = (TextView) rootview.findViewById(R.id.tv4);
        tv5 = (TextView) rootview.findViewById(R.id.tv5);
        tv6 = (TextView) rootview.findViewById(R.id.tv6);
    }

    private void getDashboardData(final View roorview) {
        Log.d("USERIDDETAIL",AppPreferences.getStrUserId("userid"));
        MyApiEndpointInterface apiService = ApiClient.getClient().create(MyApiEndpointInterface.class);

        Call<DashboardResponse> call = apiService.dashboard_data(AppPreferences.getStrUserId("userid"));//userid from appprefrence
        call.enqueue(new Callback<DashboardResponse>() {
            @Override
            public void onResponse(Call<DashboardResponse> call, Response<DashboardResponse> response) {

                try {

                    DashboardResponse dashboardResponse = response.body();

                    if(dashboardResponse.getStatus().equalsIgnoreCase("200")){
                        Log.d("RUNNINGCONDITION",dashboardResponse.getResult().getRunning()+"");

                        textView1.setText(dashboardResponse.getResult().getTotal()+""); //all
                        textView2.setText(dashboardResponse.getResult().getRunning()+"");
                        textView3.setText(dashboardResponse.getResult().getIdle()+"");
                        textView4.setText(dashboardResponse.getResult().getStop()+"");
                        textView5.setText(dashboardResponse.getResult().getOffline()+""); //inactive
                        textView6.setText(dashboardResponse.getResult().getNoData()+"");

                        //RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getActivity());




                    }
                    else if(dashboardResponse.getStatus().equalsIgnoreCase("400")){
                        Toast.makeText(getActivity(),dashboardResponse.getMessage(), Toast.LENGTH_SHORT).show();
                    }







                } catch (Exception e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Call<DashboardResponse> call, Throwable t) {
                Log.d("SSSSS33",t.toString());
            }
        });
    }

/*
    private void setTablayout(View roorview, DashboardResponse dashboardResponse) {
      ViewPager  viewPager = (ViewPager) roorview.findViewById(R.id.viewpager);
        PagerAdapter pagerAdapter = new PagerAdapter(getActivity().getSupportFragmentManager(), getActivity());
        pagerAdapter.addFragment(new AllTruckFragment());
        pagerAdapter.addFragment(new RunningFragment());
        pagerAdapter.addFragment(new IdleFragment());
        pagerAdapter.addFragment(new StopFragment());
        pagerAdapter.addFragment(new InactiveFragment());
        pagerAdapter.addFragment(new NoDataFragment());
        viewPager.setAdapter(pagerAdapter);
        TabLayout tabLayout = (TabLayout) roorview.findViewById(R.id.tab_layout);
        tabLayout.setupWithViewPager(viewPager);
        //String Date = Function.getDate();
        //Log.v(TAG, "Todays Date :- " + Date);

        //tabLayout.getTabAt(0).setText("All");
        tabLayout.getTabAt(0).setCustomView(R.layout.activity_main);
        View view =  tabLayout.getTabAt(0).getCustomView();
         txtCount= (TextView)
                view.findViewById(R.id.texttab);
        TextView textwithbg= (TextView)
                view.findViewById(R.id.textwithbg);
        txtCount.setText("All");
        textwithbg.setText(dashboardResponse.getResult().getTotal()+"");
        textwithbg.setBackgroundDrawable(getResources().getDrawable(
                R.drawable.buttondash1));
        txtCount.setBackgroundDrawable(getResources().getDrawable(
                R.drawable.button_rounded));


       // tabLayout.getTabAt(1).setText("RUNNING");
        tabLayout.getTabAt(1).setCustomView(R.layout.activity_main);
        View view1 =  tabLayout.getTabAt(1).getCustomView();
         txtCount1= (TextView)
                view1.findViewById(R.id.texttab);
        TextView textwithbg1= (TextView)
                view1.findViewById(R.id.textwithbg);
        txtCount1.setText("RUNNING");
        textwithbg1.setText(dashboardResponse.getResult().getRunning()+"");
        textwithbg1.setBackgroundDrawable(getResources().getDrawable(
                R.drawable.buttondash2));


       // tabLayout.getTabAt(2).setText("IDLE");
       // tabLayout.getTabAt(2).setCustomView(R.layout.activity_main);
        tabLayout.getTabAt(2).setCustomView(R.layout.activity_main);
        View view2 =  tabLayout.getTabAt(2).getCustomView();
         txtCount2= (TextView)
                view2.findViewById(R.id.texttab);
        TextView textwithbg2= (TextView)
                view2.findViewById(R.id.textwithbg);
        txtCount2.setText("IDLE");
        textwithbg2.setText(dashboardResponse.getResult().getIdle()+"");
        textwithbg2.setBackgroundDrawable(getResources().getDrawable(
                R.drawable.buttondash3));


        //tabLayout.getTabAt(3).setText("STOP");
       // tabLayout.getTabAt(3).setCustomView(R.layout.activity_main);
       // tabLayout.getTabAt(3).setIcon(R.drawable.buttondash4);
        tabLayout.getTabAt(3).setCustomView(R.layout.activity_main);
        View view3 =  tabLayout.getTabAt(3).getCustomView();
         txtCount3 = (TextView)
                view3.findViewById(R.id.texttab);
        TextView textwithbg3 = (TextView)
                view3.findViewById(R.id.textwithbg);
        txtCount3.setText("STOP");
        textwithbg3.setText(dashboardResponse.getResult().getStop()+"");
        textwithbg3.setBackgroundDrawable(getResources().getDrawable(
                R.drawable.buttondash4));

        //tabLayout.getTabAt(4).setCustomView(R.layout.activity_main);
        //tabLayout.getTabAt(4).setText("INACTIVE");
       /*

/* tabLayout.getTabAt(4).setText("INACTIVE");
        tabLayout.getTabAt(4).setIcon(R.drawable.buttondash5);*//*

        tabLayout.getTabAt(4).setCustomView(R.layout.activity_main);
        View view4 =  tabLayout.getTabAt(4).getCustomView();
         txtCount4 = (TextView)
                view4.findViewById(R.id.texttab);
        TextView textwithbg4 = (TextView)
                view4.findViewById(R.id.textwithbg);
        txtCount4.setText("INACTIVE");
        textwithbg4.setText(dashboardResponse.getResult().getOffline()+"");
        textwithbg4.setBackgroundDrawable(getResources().getDrawable(
                R.drawable.buttondash5));

       // tabLayout.getTabAt(5).setCustomView(R.layout.activity_main);
        //tabLayout.getTabAt(5).setText("NO DATA");
        */
/*tabLayout.getTabAt(5).setText("NO DATA");
        tabLayout.getTabAt(5).setIcon(R.drawable.buttondash6);*//*

        tabLayout.getTabAt(5).setCustomView(R.layout.activity_main);
        View view5 =  tabLayout.getTabAt(5).getCustomView();
         txtCount5 = (TextView)
                view5.findViewById(R.id.texttab);
        TextView textwithbg5 = (TextView)
                view5.findViewById(R.id.textwithbg);
        txtCount5.setText("NO DATA");
        textwithbg5.setText(dashboardResponse.getResult().getNoData()+"");
       // textwithbg5.setBackgroundResource(R.drawable.buttondash6);
        textwithbg5.setBackgroundDrawable(getResources().getDrawable(
                R.drawable.buttondash6));

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                Log.d("YYYY",tab.getPosition()+"");
                switch (tab.getPosition()) {
                    case 0:
                        //open fragment at position 0 here
                        txtCount.setBackgroundDrawable(getResources().getDrawable(
                                R.drawable.button_rounded));
                    case 1:
                        //open fragment at position 1 here
                        txtCount1.setBackgroundDrawable(getResources().getDrawable(
                                R.drawable.button_rounded));
                        break;
                        case 2:
                        //open fragment at position 2 here
                            txtCount2.setBackgroundDrawable(getResources().getDrawable(
                                    R.drawable.button_rounded));
                        break;
                        case 3:
                        //open fragment at position 3 here
                            txtCount3.setBackgroundDrawable(getResources().getDrawable(
                                    R.drawable.button_rounded));
                        break;
                        case 4:
                        //open fragment at position 4 here
                            txtCount4.setBackgroundDrawable(getResources().getDrawable(
                                    R.drawable.button_rounded));
                        break;
                        case 5:
                        //open fragment at position 5 here
                            txtCount5.setBackgroundDrawable(getResources().getDrawable(
                                    R.drawable.button_rounded));
                        break;
                }



            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                Log.d("QQQQ",tab.getPosition()+"");
                switch (tab.getPosition()) {

                    case 0:
                        //open fragment at position 0 here
                        txtCount.setBackgroundDrawable(null);
                    case 1:
                        //open fragment at position 1 here
                        txtCount1.setBackgroundDrawable(null);
                        break;
                    case 2:
                        //open fragment at position 2 here
                        txtCount2.setBackgroundDrawable(null);
                        break;
                    case 3:
                        //open fragment at position 3 here
                        txtCount3.setBackgroundDrawable(null);
                        break;
                    case 4:
                        //open fragment at position 4 here
                        txtCount4.setBackgroundDrawable(null);
                        break;
                    case 5:
                        //open fragment at position 5 here
                        txtCount5.setBackgroundDrawable(null);
                        break;
                }

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
        viewPager.setCurrentItem(0);



        }
*/
/*
    class PagerAdapter extends android.support.v4.app.FragmentStatePagerAdapter {
        Context context;
        List<Fragment> managerList = new ArrayList<Fragment>();

        public PagerAdapter(FragmentManager fm, Context context) {
            super(fm);
            this.context = context;
        }

        @Override
        public int getCount() {
            return managerList.size();
        }   //size

        public void addFragment(Fragment fragment) {
            managerList.add(fragment);
        }

        @Override
        public Fragment getItem(int position) {
            return managerList.get(position);
        }
*/
/*
        @Override
        public CharSequence getPageTitle(int position) {
            return "aaa"+position;
        }*//*

    }
*/


    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {

/*
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
*/
    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
      /*  if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }*/
    }

    @Override
    public void onDetach() {
        super.onDetach();

        //mListener = null;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.text1:


                FragmentTransaction ft = getFragmentManager().beginTransaction();
                ft.detach(TruckDetailFragment.this).attach(TruckDetailFragment.this).commit();
               /* FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.framelayout, AllTruckFragment.newInstance());
                transaction.addToBackStack(null);
                transaction.commit();*/
                break;

            case R.id.text2:

                FragmentTransaction transaction1 = getActivity().getSupportFragmentManager().beginTransaction();
                transaction1.replace(R.id.framelayout, RunningFragment.newInstance());
                transaction1.addToBackStack(null);
                transaction1.commit();
                break;

            case R.id.text3:
                FragmentTransaction transaction2 = getActivity().getSupportFragmentManager().beginTransaction();
                transaction2.replace(R.id.framelayout, IdleFragment.newInstance());
                transaction2.addToBackStack(null);
                transaction2.commit();
                break;

            case R.id.text4:

                FragmentTransaction transaction3 = getActivity().getSupportFragmentManager().beginTransaction();
                transaction3.replace(R.id.framelayout, StopFragment.newInstance());
                transaction3.addToBackStack(null);
                transaction3.commit();
                break;

            case R.id.text5:

                FragmentTransaction transaction4 = getActivity().getSupportFragmentManager().beginTransaction();
                transaction4.replace(R.id.framelayout, InactiveFragment.newInstance());
                transaction4.addToBackStack(null);
                transaction4.commit();
                break;

            case R.id.text6:

                FragmentTransaction transaction5 = getActivity().getSupportFragmentManager().beginTransaction();
                transaction5.replace(R.id.framelayout, NoDataFragment.newInstance());
                transaction5.addToBackStack(null);
                transaction5.commit();
                break;

        }

    }


/*
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
*/
}
