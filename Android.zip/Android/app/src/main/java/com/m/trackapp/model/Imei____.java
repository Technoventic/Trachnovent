package com.m.trackapp.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class Imei____  implements Serializable {

    @SerializedName("imei")
    @Expose
    private String imei;
    @SerializedName("lattitude")
    @Expose
    private String lattitude;
    @SerializedName("longitude")
    @Expose
    private String longitude;
    @SerializedName("date_server")
    @Expose
    private String dateServer;
    @SerializedName("angle")
    @Expose
    private String angle;
    @SerializedName("speed")
    @Expose
    private String speed;
    @SerializedName("ignition")
    @Expose
    private Object ignition;
    @SerializedName("battery")
    @Expose
    private Object battery;
    @SerializedName("batteryLevel")
    @Expose
    private Object batteryLevel;
    @SerializedName("distance")
    @Expose
    private Object distance;
    @SerializedName("totalDistance")
    @Expose
    private Object totalDistance;
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("sim_number")
    @Expose
    private String simNumber;
    @SerializedName("model")
    @Expose
    private String model;
    @SerializedName("status")
    @Expose
    private String status;
    @SerializedName("min_moving_speed")
    @Expose
    private Object minMovingSpeed;

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    @SerializedName("min_idle_speed")
    @Expose
    private Object minIdleSpeed;

    @SerializedName("min_fuel_speed")
    @Expose
    private Object minFuelSpeed;


    @SerializedName("img")
    @Expose
    private String img;

    @SerializedName("img_top")
    @Expose
    private String img_top;

    @SerializedName("ac")
    @Expose
    private String ac;

    @SerializedName("fuel")
    @Expose
    private String fuel;

    @SerializedName("duration")
    @Expose
    private String duration;





    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public String getLattitude() {
        return lattitude;
    }

    public void setLattitude(String lattitude) {
        this.lattitude = lattitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getDateServer() {
        return dateServer;
    }

    public void setDateServer(String dateServer) {
        this.dateServer = dateServer;
    }

    public String getAngle() {
        return angle;
    }

    public void setAngle(String angle) {
        this.angle = angle;
    }

    public String getSpeed() {
        return speed;
    }

    public void setSpeed(String speed) {
        this.speed = speed;
    }

    public Object getIgnition() {
        return ignition;
    }

    public void setIgnition(Object ignition) {
        this.ignition = ignition;
    }

    public Object getBattery() {
        return battery;
    }

    public void setBattery(Object battery) {
        this.battery = battery;
    }

    public Object getBatteryLevel() {
        return batteryLevel;
    }

    public void setBatteryLevel(Object batteryLevel) {
        this.batteryLevel = batteryLevel;
    }

    public Object getDistance() {
        return distance;
    }

    public void setDistance(Object distance) {
        this.distance = distance;
    }

    public Object getTotalDistance() {
        return totalDistance;
    }

    public void setTotalDistance(Object totalDistance) {
        this.totalDistance = totalDistance;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSimNumber() {
        return simNumber;
    }

    public void setSimNumber(String simNumber) {
        this.simNumber = simNumber;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Object getMinMovingSpeed() {
        return minMovingSpeed;
    }

    public void setMinMovingSpeed(Object minMovingSpeed) {
        this.minMovingSpeed = minMovingSpeed;
    }

    public Object getMinIdleSpeed() {
        return minIdleSpeed;
    }

    public void setMinIdleSpeed(Object minIdleSpeed) {
        this.minIdleSpeed = minIdleSpeed;
    }

    public Object getMinFuelSpeed() {
        return minFuelSpeed;
    }

    public void setMinFuelSpeed(Object minFuelSpeed) {
        this.minFuelSpeed = minFuelSpeed;
    }

    public String getImg_top() {
        return img_top;
    }

    public void setImg_top(String img_top) {
        this.img_top = img_top;
    }

    public String getAc() {
        return ac;
    }

    public void setAc(String ac) {
        this.ac = ac;
    }

    public String getFuel() {
        return fuel;
    }

    public void setFuel(String fuel) {
        this.fuel = fuel;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }
}
