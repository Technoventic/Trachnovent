package com.m.trackapp.fragment;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;

import android.graphics.drawable.Drawable;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.BottomSheetBehavior;
import android.support.design.widget.CoordinatorLayout;
import android.support.v4.app.Fragment;

import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;


import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;

import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.m.trackapp.R;
import com.m.trackapp.RetrofitClasses.ApiClient;
import com.m.trackapp.RetrofitClasses.MyApiEndpointInterface;
import com.m.trackapp.Utility.AppPreferences;
import com.m.trackapp.Utility.FontAwesome;
import com.m.trackapp.model.AllTruckResponse;
import com.m.trackapp.model.DashboardResponse;
import com.m.trackapp.model.Imei;
import com.m.trackapp.model.Imei_;
import com.m.trackapp.model.Imei__;
import com.m.trackapp.model.Imei___;
import com.m.trackapp.model.Imei____;
import com.m.trackapp.model.Imei_____;


import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.content.ContentValues.TAG;


public class ItemOneFragment extends Fragment implements OnMapReadyCallback,View.OnClickListener {

    private GoogleMap mMap;
    MapView mapView;
    View rootview;
    FontAwesome threedots_img, btnplus, btnminus;
    PopupWindow pw;
    Button tvTripOnMap;
    Button textView1, textView2, textView3, textView4, textView5, textView6;
    TextView cordinateHeading,tvStatus,tvAddress;
    //TextView tv1,tv2,tv3,tv4,tv5,tv6;
    double lat = 0.0,longi = 0.0;
    LinearLayout linearAllButton;
    // BottomSheetBehavior variable
    private BottomSheetBehavior bottomSheetBehavior;
    CoordinatorLayout bottomCordinate;

    List<Imei_____> stringlatlonglist = new ArrayList<Imei_____>();
    List<Imei> stringrunningList = new ArrayList<Imei>();
    List<Imei__> stringIdleList = new ArrayList<Imei__>();
    List<Imei_> stringStopList = new ArrayList<Imei_>();
    List<Imei____> stringOFFLINEList = new ArrayList<Imei____>();
    List<Imei___> stringNODATAList = new ArrayList<Imei___>();
    Imei_____    modall;
    Imei modalRunning;
    Imei__ modalIdle;
    Imei_ modalStop;
    Imei____ modalInactive;
    Imei___ modalNodata;

    String buttonClick ="ALL",truckNo = "";
    int maptyp = 1;



    public ItemOneFragment() {
        // Required empty public constructor
    }

    public static ItemOneFragment newInstance() {
        ItemOneFragment fragment = new ItemOneFragment();
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootview = inflater.inflate(R.layout.fragment_item_one, container, false);
        init(rootview);
        bottomCordinate.setVisibility(View.GONE);

        if (getArguments() != null) {
            linearAllButton.setVisibility(View.GONE);
            buttonClick = "OTHER";

              modall = (Imei_____)getArguments().getSerializable("MODALL");
            modalRunning = (Imei)getArguments().getSerializable("MODALLRUNNING");
            modalIdle = (Imei__)getArguments().getSerializable("MODALLIDLE");

            modalStop = (Imei_)getArguments().getSerializable("MODALLSTOP");
            modalInactive = (Imei____)getArguments().getSerializable("MODALLINACTIVE");
            modalNodata = (Imei___)getArguments().getSerializable("MODALLNODATA");
            bottomCordinate.setVisibility(View.VISIBLE);

            if(getArguments().getSerializable("MODALL") != null) {

                lat = Double.parseDouble(modall.getLattitude()+"");
                longi = Double.parseDouble(modall.getLongitude()+"");
                truckNo = modall.getName();
                cordinateHeading.setText(truckNo);
                tvStatus.setText(modall.getStatus());
            }
            else if(getArguments().getSerializable("MODALLRUNNING") != null){
                lat = Double.parseDouble(modalRunning.getLattitude()+"");
                longi = Double.parseDouble(modalRunning.getLongitude()+"");
                truckNo = modalRunning.getName();
                cordinateHeading.setText(truckNo);
                tvStatus.setText(modalRunning.getStatus());
            }
            else if(getArguments().getSerializable("MODALLIDLE") != null){
                lat = Double.parseDouble(modalIdle.getLattitude()+"");
                longi = Double.parseDouble(modalIdle.getLongitude()+"");
                truckNo = modalIdle.getName();
                cordinateHeading.setText(truckNo);
                tvStatus.setText(modalIdle.getStatus());
            }
            else if(getArguments().getSerializable("MODALLSTOP") != null){
                lat = Double.parseDouble(modalStop.getLattitude()+"");
                longi = Double.parseDouble(modalStop.getLongitude()+"");
                truckNo = modalStop.getName();
                cordinateHeading.setText(truckNo);
                tvStatus.setText(modalStop.getStatus());
            }
            else if(getArguments().getSerializable("MODALLINACTIVE") != null){
                lat = Double.parseDouble(modalInactive.getLattitude()+"");
                longi = Double.parseDouble(modalInactive.getLongitude()+"");
                truckNo = modalInactive.getName();
                cordinateHeading.setText(truckNo);
                tvStatus.setText(modalInactive.getStatus());
            }
            else if(getArguments().getSerializable("MODALLNODATA") != null){
                lat = Double.parseDouble(modalNodata.getLattitude()+"");
                longi = Double.parseDouble(modalNodata.getLongitude()+"");
                truckNo = modalNodata.getName();
                cordinateHeading.setText(truckNo);
                tvStatus.setText(modalNodata.getStatus());
            }

/*
           else if(!modalInactive.getName().isEmpty()){
                Log.d("*****","999999");
                bottomCordinate.setVisibility(View.VISIBLE);
                lat = Double.parseDouble(modalInactive.getLattitude()+"");
                longi = Double.parseDouble(modalInactive.getLongitude()+"");
                truckNo = modalInactive.getName();
                bottomCordinate.setVisibility(View.VISIBLE);
                cordinateHeading.setText(truckNo);
                tvSpeed.setText(modalInactive.getSpeed());
            }
*/


           // tvFuel.setText("");
              //  Log.d("NNNNNN",modall.getName());
           // getAllTruckDetails(buttonClick);
          //  refreshFragment();

        }



        getDashboardData();
        getAllTruckDetails(buttonClick);

        bottomSheetBehavior.setBottomSheetCallback(new BottomSheetBehavior.BottomSheetCallback() {
            @Override
            public void onStateChanged(View bottomSheet, int newState) {

                if (newState == BottomSheetBehavior.STATE_EXPANDED) {
                    //bottomSheetHeading.setText("TEXT COLLEPSE ME");
                } else {
                 //   bottomSheetHeading.setText("TEXT EXPAND ME");
                }

                // Check Logs to see how bottom sheets behaves
                switch (newState) {
                    case BottomSheetBehavior.STATE_COLLAPSED:
                        Log.e("Bottom Sheet Behaviour", "STATE_COLLAPSED");
                        break;
                    case BottomSheetBehavior.STATE_DRAGGING:
                        Log.e("Bottom Sheet Behaviour", "STATE_DRAGGING");
                        break;
                    case BottomSheetBehavior.STATE_EXPANDED:
                        Log.e("Bottom Sheet Behaviour", "STATE_EXPANDED");
                        break;
                    case BottomSheetBehavior.STATE_HIDDEN:
                        Log.e("Bottom Sheet Behaviour", "STATE_HIDDEN");
                        break;
                    case BottomSheetBehavior.STATE_SETTLING:
                        Log.e("Bottom Sheet Behaviour", "STATE_SETTLING");
                        break;
                }
            }


            @Override
            public void onSlide(View bottomSheet, float slideOffset) {

            }
        });


        threedots_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //  showPopup(v);
                initiatePopupWindow(rootview);
            }
        });

       tvTripOnMap.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {

        FragmentManager fm = getFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        TripOnMapFragment llf = new TripOnMapFragment();
        ft.replace(R.id.frame_layout, llf);
        ft.addToBackStack(null);
        ft.commit();

       }
     });
        return rootview;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mapView = (MapView) rootview.findViewById(R.id.mapview);
        if (mapView != null) {
            mapView.onCreate(null);
            mapView.onResume();
            mapView.getMapAsync(this);
        }
    }

    private void getAllTruckDetails(final String buttonClick) {
        Log.d("BUTTONCLICK>>",buttonClick);
        MyApiEndpointInterface apiService = ApiClient.getClient().create(MyApiEndpointInterface.class);

        Call<AllTruckResponse> call = apiService.all_truck_details_list(AppPreferences.getStrUserId("userid"));//userid from appprefrence
        call.enqueue(new Callback<AllTruckResponse>() {
            @Override
            public void onResponse(Call<AllTruckResponse> call, Response<AllTruckResponse> response) {

                AllTruckResponse allTruckResponse = response.body();

                for (int i = 0; i < allTruckResponse.getResult().size(); i++) {
                    if(buttonClick.equalsIgnoreCase("ALL")){
                        for (int j = 0; j < allTruckResponse.getResult().get(i).getTotal().get(i).getImei().size(); j++) {
                            Log.d("LATITUTE", allTruckResponse.getResult().get(i).getTotal().get(i).getImei().get(j).getLattitude());
                            stringlatlonglist.add(allTruckResponse.getResult().get(i).getTotal().get(i).getImei().get(j));
                            Log.d("BUTTONVALue>>",buttonClick);



                        }

                    }
                    else if(buttonClick.equalsIgnoreCase("RUNNING")){
                        for (int j = 0; j < allTruckResponse.getResult().get(i).getRunning().get(i).getImei().size(); j++) {
                            Log.d("LATITUTERuunning", allTruckResponse.getResult().get(i).getRunning().get(i).getImei().get(j).getLattitude());
                            stringrunningList.add(allTruckResponse.getResult().get(i).getRunning().get(i).getImei().get(j));

                            }

                    }

                    else if(buttonClick.equalsIgnoreCase("IDLE")){
                        for (int j = 0; j < allTruckResponse.getResult().get(i).getIdle().get(i).getImei().size(); j++) {
                            Log.d("LATITUTEIDLE", allTruckResponse.getResult().get(i).getIdle().get(i).getImei().get(j).getLattitude()+"");
                            stringIdleList.add(allTruckResponse.getResult().get(i).getIdle().get(i).getImei().get(j));

                        }

                    }
                    else if(buttonClick.equalsIgnoreCase("STOP")){
                        for (int j = 0; j < allTruckResponse.getResult().get(i).getStop().get(i).getImei().size(); j++) {
                            Log.d("LATITUTESTOP", allTruckResponse.getResult().get(i).getStop().get(i).getImei().get(j).getLattitude()+"");
                            stringStopList.add(allTruckResponse.getResult().get(i).getStop().get(i).getImei().get(j));

                        }

                    }
                    else if(buttonClick.equalsIgnoreCase("INACTIVE")){
                        for (int j = 0; j < allTruckResponse.getResult().get(i).getOffline().get(i).getImei().size(); j++) {
                            Log.d("LATITUTEOFFLINE", allTruckResponse.getResult().get(i).getOffline().get(i).getImei().get(j).getLattitude()+"");
                            stringOFFLINEList.add(allTruckResponse.getResult().get(i).getOffline().get(i).getImei().get(j));

                        }

                    }
                    else if(buttonClick.equalsIgnoreCase("NODATA")){
                        for (int j = 0; j < allTruckResponse.getResult().get(i).getNoData().get(i).getImei().size(); j++) {
                            Log.d("LATITUTENODATA", allTruckResponse.getResult().get(i).getNoData().get(i).getImei().get(j).getLattitude()+"");
                            stringNODATAList.add(allTruckResponse.getResult().get(i).getNoData().get(i).getImei().get(j));

                        }

                    }


                }


                }

            @Override
            public void onFailure(Call<AllTruckResponse> call, Throwable t) {
                Log.d("SSSSS33", t.toString());
            }
        });

    }


    private void init(View rootview) {
       linearAllButton = (LinearLayout)rootview.findViewById(R.id.linear);
        bottomCordinate = (CoordinatorLayout) rootview.findViewById(R.id.cordinatView);
        cordinateHeading = (TextView) rootview.findViewById(R.id.bottomSheetHeading);
        tvAddress = (TextView) rootview.findViewById(R.id.tvAddress);
        tvStatus = (TextView) rootview.findViewById(R.id.tvStatus);
        tvTripOnMap = (Button) rootview.findViewById(R.id.btnTripOnMap);
        bottomSheetBehavior = BottomSheetBehavior.from(rootview.findViewById(R.id.bottomSheetLayout));
        bottomSheetBehavior.setHideable(false); //Important to add

        threedots_img = (FontAwesome) rootview.findViewById(R.id.btn2);
        btnplus = (FontAwesome) rootview.findViewById(R.id.btnplus);
        btnminus = (FontAwesome) rootview.findViewById(R.id.btnminus);

        textView1 = (Button) rootview.findViewById(R.id.text1);
        textView2 = (Button) rootview.findViewById(R.id.text2);
        textView3 = (Button) rootview.findViewById(R.id.text3);
        textView4 = (Button) rootview.findViewById(R.id.text4);
        textView5 = (Button) rootview.findViewById(R.id.text5);
        textView6 = (Button) rootview.findViewById(R.id.text6);

      /*  tv1 = (TextView) rootview.findViewById(R.id.tv1);
        tv2 = (TextView) rootview.findViewById(R.id.tv2);
        tv3 = (TextView) rootview.findViewById(R.id.tv3);
        tv4 = (TextView) rootview.findViewById(R.id.tv4);
        tv5 = (TextView) rootview.findViewById(R.id.tv5);
        tv6 = (TextView) rootview.findViewById(R.id.tv6);*/


        ((Button) rootview.findViewById(R.id.text1)).setOnClickListener(this);
        ((Button) rootview.findViewById(R.id.text2)).setOnClickListener(this);
        ((Button) rootview.findViewById(R.id.text3)).setOnClickListener(this);
        ((Button) rootview.findViewById(R.id.text4)).setOnClickListener(this);
        ((Button) rootview.findViewById(R.id.text5)).setOnClickListener(this);
        ((Button) rootview.findViewById(R.id.text6)).setOnClickListener(this);

        // tv1.setTextColor(getResources().getColor(R.color.black));



    }

    private void getDashboardData() {
        MyApiEndpointInterface apiService = ApiClient.getClient().create(MyApiEndpointInterface.class);

        Call<DashboardResponse> call = apiService.dashboard_data(AppPreferences.getStrUserId("userid"));//userid from appprefrence
        call.enqueue(new Callback<DashboardResponse>() {
            @Override
            public void onResponse(Call<DashboardResponse> call, Response<DashboardResponse> response) {

                try {

                    DashboardResponse dashboardResponse = response.body();

                    if (dashboardResponse.getStatus().equalsIgnoreCase("200")) {
                        Log.d("RUNNINGCONDITION", dashboardResponse.getResult().getRunning() + "");
                        textView1.setText(dashboardResponse.getResult().getTotal() + ""); //all
                        textView2.setText(dashboardResponse.getResult().getRunning() + "");
                        textView3.setText(dashboardResponse.getResult().getIdle() + "");
                        textView4.setText(dashboardResponse.getResult().getStop() + "");
                        textView5.setText(dashboardResponse.getResult().getOffline() + ""); //inactive
                        textView6.setText(dashboardResponse.getResult().getNoData() + "");



                    } else if (dashboardResponse.getStatus().equalsIgnoreCase("400")) {
                        Toast.makeText(getActivity(), dashboardResponse.getMessage(), Toast.LENGTH_SHORT).show();
                    }


                } catch (Exception e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Call<DashboardResponse> call, Throwable t) {
                Log.d("SSSSS33", t.toString());
            }
        });
    }

    private void initiatePopupWindow(View rootview) {
        try {
            List<String> items = new ArrayList<String>();
            items.add("Satelite");
            items.add("Normal");
            items.add("Hybrid");
            items.add("Terrain");


            LayoutInflater inflater = (LayoutInflater) getActivity()
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

            View layout = inflater.inflate(R.layout.custom_popup,
                    (ViewGroup) rootview.findViewById(R.id.popup_element));

            pw = new PopupWindow(layout, 320, 420, true);
            pw.showAtLocation(layout, Gravity.CENTER, 0, 0);


            ListView listView = (ListView) layout.findViewById(R.id.listview);

            ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>
                    (getActivity(), android.R.layout.simple_list_item_1, items) {
                @Override
                public View getView(int position, View convertView, ViewGroup parent) {

                    View view = super.getView(position, convertView, parent);
                    TextView tv = (TextView) view.findViewById(android.R.id.text1);
                    tv.setTextColor(Color.WHITE);
                    return view;
                }
            };

            // DataBind ListView with items from ArrayAdapter
            listView.setAdapter(arrayAdapter);
            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view,
                                        int position, long id) {
                    maptyp = position;

                    Toast.makeText(getActivity(),
                            "Click ListItem Number " + position, Toast.LENGTH_LONG)
                            .show();
                    pw.dismiss();
                    refreshFragment();
                }
            });

            } catch (Exception e) {
            e.printStackTrace();
        }
    }




    @Override
    public void onMapReady(final GoogleMap googleMap) {
        MapsInitializer.initialize(getContext());
        mMap = googleMap;
        mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
        if(maptyp == 0 || AppPreferences.getMapType("Maptype").equalsIgnoreCase("Satelite")){
            mMap.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
        }
        if(maptyp == 1 || AppPreferences.getMapType("Maptype").equalsIgnoreCase("Normal")){
            mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
        }
        else if(maptyp == 2 || AppPreferences.getMapType("Maptype").equalsIgnoreCase("Hybrid")){
            mMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);

        } else if(maptyp == 3 || AppPreferences.getMapType("Maptype").equalsIgnoreCase("Terrain")){
            mMap.setMapType(GoogleMap.MAP_TYPE_TERRAIN);
        }

        btnminus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mMap.animateCamera(CameraUpdateFactory.zoomOut());
            }
        });


      /*  googleMap.addMarker(new MarkerOptions().position(new LatLng(40.689247,-74.044502)).title("Libarty stetue").snippet("I hope to you in gujrat"));
        CameraPosition cameraPosition =CameraPosition.builder().target(new LatLng(40.689247,-74.044502)).zoom(16).bearing(0).tilt(45).build();
        googleMap.moveCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));*/

        mMap.setOnMapLoadedCallback(new GoogleMap.OnMapLoadedCallback() {
            @Override
            public void onMapLoaded() {
                Log.d("UPDATEMAP>>",buttonClick);
                Drawable background = ContextCompat.getDrawable(getActivity(), R.drawable.ic_deliverytruck);
                background.setBounds(0, 0, background.getIntrinsicWidth(), background.getIntrinsicHeight());
                Drawable vectorDrawable = ContextCompat.getDrawable(getActivity(), R.drawable.ic_deliverytruck);
                vectorDrawable.setBounds(40, 20, vectorDrawable.getIntrinsicWidth() + 40, vectorDrawable.getIntrinsicHeight() + 20);
                Bitmap bitmap = Bitmap.createBitmap(background.getIntrinsicWidth(), background.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
                Canvas canvas = new Canvas(bitmap);
                background.draw(canvas);
                vectorDrawable.draw(canvas);

                   if(buttonClick.equalsIgnoreCase("OTHER")){
                       LatLng latLng = new LatLng(lat, longi);

                    MarkerOptions markerOpt = new MarkerOptions();
                    markerOpt.position(latLng)
                            .title(truckNo)
                            //.snippet(stringlatlonglist.get(i).getDateServer() + "\nContact No. " + stringlatlonglist.get(i).getSimNumber())
                            .icon(BitmapDescriptorFactory.fromBitmap(bitmap));

                    googleMap.addMarker(markerOpt).showInfoWindow();
                    //CameraPosition cameraPosition =CameraPosition.builder().target(new LatLng(lat,longi)).zoom(25).bearing(0).tilt(45).build(); //zoom 16
                    //googleMap.moveCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
                       googleMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
                       googleMap.animateCamera(CameraUpdateFactory.zoomTo(11));
                }


                for (final Imei_____ listItem : stringlatlonglist) {
                    Log.e(TAG, "onMapLoaded: listItem >> " + stringlatlonglist.size()+"");



                    if (listItem.getLongitude() != null && !listItem.getLattitude().equalsIgnoreCase("") && listItem.getLongitude() != null && !listItem.getLongitude().equalsIgnoreCase("")) {

                        if(buttonClick.equalsIgnoreCase("ALL")){
                            for(int i = 0; i< stringlatlonglist.size(); i++){
                                LatLng latLng = new LatLng(Double.parseDouble(stringlatlonglist.get(i).getLattitude()), Double.parseDouble(stringlatlonglist.get(i).getLongitude()));
                                //Log.d("IMAGE URL>>>",stringlatlonglist.get(i).getImg_top());
                               /* Drawable background = ContextCompat.getDrawable(getActivity(), R.drawable.ic_deliverytruck);
                                background.setBounds(0, 0, background.getIntrinsicWidth(), background.getIntrinsicHeight());
                                Drawable vectorDrawable = ContextCompat.getDrawable(getActivity(), R.drawable.ic_deliverytruck);
                                vectorDrawable.setBounds(40, 20, vectorDrawable.getIntrinsicWidth() + 40, vectorDrawable.getIntrinsicHeight() + 20);
                                Bitmap bitmap = Bitmap.createBitmap(background.getIntrinsicWidth(), background.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
                                Canvas canvas = new Canvas(bitmap);
                                background.draw(canvas);
                                vectorDrawable.draw(canvas);*/

                                MarkerOptions markerOpt = new MarkerOptions();
                                markerOpt.position(latLng)
                                        .title(stringlatlonglist.get(i).getName())
                                        //.snippet(stringlatlonglist.get(i).getDateServer() + "\nContact No. " + stringlatlonglist.get(i).getSimNumber())
                                        .icon(BitmapDescriptorFactory.fromBitmap(bitmap));

                                googleMap.addMarker(markerOpt).showInfoWindow();
                                CameraPosition cameraPosition =CameraPosition.builder().target(new LatLng(Double.parseDouble(stringlatlonglist.get(i).getLattitude()),Double.parseDouble(stringlatlonglist.get(i).getLongitude()))).zoom(5).bearing(0).tilt(45).build(); //zoom 16
                                googleMap.moveCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));

                            }

                        }
                        else if(buttonClick.equalsIgnoreCase("RUNNING")){
                            for(int i = 0; i< stringrunningList.size(); i++){
                                LatLng latLng = new LatLng(Double.parseDouble(stringrunningList.get(i).getLattitude()), Double.parseDouble(stringrunningList.get(i).getLongitude()));

                                MarkerOptions markerOpt = new MarkerOptions();
                                markerOpt.position(latLng)
                                        .title(stringrunningList.get(i).getName())
                                        //.snippet(stringlatlonglist.get(i).getDateServer() + "\nContact No. " + stringlatlonglist.get(i).getSimNumber())
                                        .icon(BitmapDescriptorFactory.fromBitmap(bitmap));

                                googleMap.addMarker(markerOpt).showInfoWindow();
                                CameraPosition cameraPosition =CameraPosition.builder().target(new LatLng(Double.parseDouble(stringrunningList.get(i).getLattitude()),Double.parseDouble(stringrunningList.get(i).getLongitude()))).zoom(5).bearing(0).tilt(45).build(); //zoom 16
                                googleMap.moveCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
                            }

                        }

                        else if(buttonClick.equalsIgnoreCase("IDLE")){
                            for(int i = 0; i< stringIdleList.size(); i++){
                                LatLng latLng = new LatLng(Double.parseDouble(stringIdleList.get(i).getLattitude()+""), Double.parseDouble(stringIdleList.get(i).getLongitude()+""));

                                MarkerOptions markerOpt = new MarkerOptions();
                                markerOpt.position(latLng)
                                        .title(stringIdleList.get(i).getName())
                                        //.snippet(stringlatlonglist.get(i).getDateServer() + "\nContact No. " + stringlatlonglist.get(i).getSimNumber())
                                        .icon(BitmapDescriptorFactory.fromBitmap(bitmap));

                                googleMap.addMarker(markerOpt).showInfoWindow();
                                CameraPosition cameraPosition =CameraPosition.builder().target(new LatLng(Double.parseDouble(stringIdleList.get(i).getLattitude()+""),Double.parseDouble(stringIdleList.get(i).getLongitude()+""))).zoom(5).bearing(0).tilt(45).build(); //zoom 16
                                googleMap.moveCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
                            }

                        }

                        else if(buttonClick.equalsIgnoreCase("STOP")){
                            for(int i = 0; i< stringStopList.size(); i++){
                                LatLng latLng = new LatLng(Double.parseDouble(stringStopList.get(i).getLattitude()+""), Double.parseDouble(stringStopList.get(i).getLongitude()+""));

                                MarkerOptions markerOpt = new MarkerOptions();
                                markerOpt.position(latLng)
                                        .title(stringStopList.get(i).getName())
                                        //.snippet(stringlatlonglist.get(i).getDateServer() + "\nContact No. " + stringlatlonglist.get(i).getSimNumber())
                                        .icon(BitmapDescriptorFactory.fromBitmap(bitmap));

                                googleMap.addMarker(markerOpt).showInfoWindow();
                                CameraPosition cameraPosition =CameraPosition.builder().target(new LatLng(Double.parseDouble(stringStopList.get(i).getLattitude()+""),Double.parseDouble(stringStopList.get(i).getLongitude()+""))).zoom(5).bearing(0).tilt(45).build(); //zoom 16
                                googleMap.moveCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
                            }

                        }
                        else if(buttonClick.equalsIgnoreCase("INACTIVE")){
                            for(int i = 0; i< stringOFFLINEList.size(); i++){
                                LatLng latLng = new LatLng(Double.parseDouble(stringOFFLINEList.get(i).getLattitude()+""), Double.parseDouble(stringOFFLINEList.get(i).getLongitude()+""));

                                MarkerOptions markerOpt = new MarkerOptions();
                                markerOpt.position(latLng)
                                        .title(stringOFFLINEList.get(i).getName())
                                        //.snippet(stringlatlonglist.get(i).getDateServer() + "\nContact No. " + stringlatlonglist.get(i).getSimNumber())
                                        .icon(BitmapDescriptorFactory.fromBitmap(bitmap));

                                googleMap.addMarker(markerOpt).showInfoWindow();
                                CameraPosition cameraPosition =CameraPosition.builder().target(new LatLng(Double.parseDouble(stringOFFLINEList.get(i).getLattitude()+""),Double.parseDouble(stringOFFLINEList.get(i).getLongitude()+""))).zoom(5).bearing(0).tilt(45).build(); //zoom 16
                                googleMap.moveCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
                            }

                        }
                        else if(buttonClick.equalsIgnoreCase("NODATA")){
                            for(int i = 0; i< stringNODATAList.size(); i++){
                                LatLng latLng = new LatLng(Double.parseDouble(stringNODATAList.get(i).getLattitude()+""), Double.parseDouble(stringNODATAList.get(i).getLongitude()+""));

                                MarkerOptions markerOpt = new MarkerOptions();
                                markerOpt.position(latLng)
                                        .title(stringNODATAList.get(i).getName())
                                        //.snippet(stringlatlonglist.get(i).getDateServer() + "\nContact No. " + stringlatlonglist.get(i).getSimNumber())
                                        .icon(BitmapDescriptorFactory.fromBitmap(bitmap));

                                googleMap.addMarker(markerOpt).showInfoWindow();
                                CameraPosition cameraPosition =CameraPosition.builder().target(new LatLng(Double.parseDouble(stringNODATAList.get(i).getLattitude()+""),Double.parseDouble(stringNODATAList.get(i).getLongitude()+""))).zoom(5).bearing(0).tilt(45).build(); //zoom 16
                                googleMap.moveCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
                            }

                        }




                    }



            }

            }
        });


    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.text1:
                buttonClick = "ALL";
                getAllTruckDetails(buttonClick);
                refreshFragment();
                break;

            case R.id.text2:
                buttonClick = "RUNNING";
                getAllTruckDetails(buttonClick);
                refreshFragment();
                break;

            case R.id.text3:
                buttonClick = "IDLE";
                getAllTruckDetails(buttonClick);
                refreshFragment();
                break;

            case R.id.text4:
                buttonClick = "STOP";
                getAllTruckDetails(buttonClick);
                refreshFragment();
                break;

            case R.id.text5:
                buttonClick = "INACTIVE";
                getAllTruckDetails(buttonClick);
                refreshFragment();
                break;

                case R.id.text6:
                    buttonClick = "NODATA";
                    getAllTruckDetails(buttonClick);
                    refreshFragment();
                    break;

                }


    }

    private void refreshFragment() {
        FragmentTransaction ft = getFragmentManager().beginTransaction();
        ft.detach(ItemOneFragment.this).attach(ItemOneFragment.this).commit();
    }
    public class AsyncTaskLoadImage  extends AsyncTask<String, String, Bitmap> {
        private final static String TAG = "AsyncTaskLoadImage";
        private ImageView imageView;
        public AsyncTaskLoadImage() {
            //  this.imageView = imageView;
        }
        @Override
        protected Bitmap doInBackground(String... params) {
            Bitmap bitmap = null;
            try {
                URL url = new URL(params[0]);
                bitmap = BitmapFactory.decodeStream((InputStream)url.getContent());

            } catch (IOException e) {
                Log.e(TAG, e.getMessage());
            }
            return bitmap;
        }
        @Override
        protected void onPostExecute(Bitmap bitmap) {
            Log.d("MMMMM",bitmap.toString());
//        imageView.setImageBitmap(bitmap);
        }
    }

  /* btnplus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mMap.animateCamera(CameraUpdateFactory.zoomIn());
            }
        });
        btnminus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mMap.animateCamera(CameraUpdateFactory.zoomOut());
            }
        });*//*


      */
    /*if(ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            lm.requestLocationUpdates(lm.NETWORK_PROVIDER, 0, 0, ll);
        }

        pos = new LatLng(l.getLatitude(), l.getLongitude());

        // Add a marker in Sydney and move the camera
        mMap.setMyLocationEnabled(true);
        mMap.addMarker(new MarkerOptions().position(pos).title("Marker in Sydney"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(pos));*/
    }
/*

    }
*/


//linearAll,linearRunning,linearIdle,linearStop,linearInactive,linearNoDATA





