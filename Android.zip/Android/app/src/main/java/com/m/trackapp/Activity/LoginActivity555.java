package com.m.trackapp.Activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.m.trackapp.R;
import com.m.trackapp.RetrofitClasses.ApiClient;
import com.m.trackapp.RetrofitClasses.MyApiEndpointInterface;
import com.m.trackapp.Utility.AppPreferences;
import com.m.trackapp.model.LoginRequest;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity555 extends AppCompatActivity {
    EditText etEmail,etPassword;
    TextView tvForgotPassword;
    Button btnlogin;
    CheckBox checkRememberme;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
/*
        if(AppPreferences.getStringPref(this).equalsIgnoreCase("HOME")){
            startActivity(new Intent(LoginActivity555.this,DashboardActivity.class));
        }
*/
        setContentView(R.layout.activity_login);
        tvForgotPassword =  (TextView)findViewById(R.id.forgotPassword);
        checkRememberme =  (CheckBox)findViewById(R.id.rememberme);
        btnlogin =  (Button)findViewById(R.id.btnLogin);
        tvForgotPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity555.this,ForgotPassword.class));
            }
        });

     /*   btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity.this,DashboardActivity.class));
            }
        });*/


        etEmail =  (EditText)findViewById(R.id.etEmailid);
        etPassword =  (EditText)findViewById(R.id.etPassword);
        //btnSubmit = (Button)findViewById(R.id.btnSubmit);

        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String data1 = etEmail.getText().toString().trim();
                String data2 = etPassword.getText().toString().trim();
                boolean invalid = false;

                if(data1.equals("")){
                    invalid = true;
                    Toast.makeText(getApplicationContext(), "Email ID Missing", Toast.LENGTH_SHORT).show();
                }else if(data2.equals("")){
                    invalid = true;
                    Toast.makeText(getApplicationContext(), "Password Missing", Toast.LENGTH_SHORT).show();
                }
                if(invalid == false){
                    getData();
                }


            }
        });

    }

    private void getData() {
        //  final   Gson gson = new Gson();
        MyApiEndpointInterface apiService = ApiClient.getClient().create(MyApiEndpointInterface.class);
        Call<LoginRequest> call = apiService.getLoginDetail(etEmail.getText().toString(),etPassword.getText().toString(),"0");
        call.enqueue(new Callback<LoginRequest>() {
            @Override
            public void onResponse(Call<LoginRequest> call, Response<LoginRequest> response) {

                try {

                    Log.d("SSSSS",response.body().toString());
                    LoginRequest loginResult =  response.body();
                   // AppPreferences.setStringPref(LoginActivity555.this,loginResult.getResult().getUserId());

                    if(loginResult.getStatus().equalsIgnoreCase("200")){
                        startActivity(new Intent(LoginActivity555.this,DashboardActivity.class));

                        etEmail.setText("");
                        etPassword.setText("");
                        finish();
                    }
                    else if(loginResult.getStatus().equalsIgnoreCase("400")){
                        Toast.makeText(LoginActivity555.this, "email id or password not matched", Toast.LENGTH_SHORT).show();
                    }






                } catch (Exception e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Call<LoginRequest> call, Throwable t) {
                Log.d("SSSSS33",t.toString());
            }
        });
/*
        call.enqueue(new Callback<List<LoginResult>>() {
            @Override
            public void onResponse(Call<List<LoginResult>> call, Response<List<LoginResult>> response) {
                Log.d("WWWWW",response.body().toString());



            }

            @Override
            public void onFailure(Call<List<LoginResult>> call, Throwable t) {
                Log.e("MainActivity", t.toString());
                //    progressDoalog.dismiss();
            }
        });
*/


    }
}
