package com.m.trackapp.RetrofitClasses;

import com.m.trackapp.Utility.AppConstant;
import com.m.trackapp.model.AboutUsResult;
import com.m.trackapp.model.AllTruckResponse;

import com.m.trackapp.model.AllTruckdetailResult;
import com.m.trackapp.model.ChangePasswordResponse;
import com.m.trackapp.model.DashboardNewResponse;
import com.m.trackapp.model.DashboardNewResult;
import com.m.trackapp.model.DashboardResponse;
import com.m.trackapp.model.ForgotPasswordResponse;
import com.m.trackapp.model.HelpAndSupportResponse;
import com.m.trackapp.model.HomeScreenResponse;
import com.m.trackapp.model.LoginRequest;
import com.m.trackapp.model.LoginResult;

import java.util.List;
import java.util.Map;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Response;
import retrofit2.http.Field;
import retrofit2.http.FieldMap;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Query;


public interface MyApiEndpointInterface {

   @FormUrlEncoded
    @POST(AppConstant.ENDPOINT.FIRSTPAGE)
   // Call<ResponseBody> getLoginDetail(@Query("email") String email,@Query("password") String password);
    Call<LoginRequest> getLoginDetail(@Field("email") String email,@Field("password") String password,@Field("remember_me") String remember_me);


    @FormUrlEncoded
    @POST(AppConstant.ENDPOINT.FORGOTPASSWORD)
    Call<ForgotPasswordResponse> getForgotPassword(@Field("emailid") String email, @Field("userid") String userid);

    @FormUrlEncoded
    @POST(AppConstant.ENDPOINT.DASHBOARD)
    Call<DashboardResponse> dashboard_data(@Field("user_id") String userid);


 @FormUrlEncoded
    @POST(AppConstant.ENDPOINT.ABOUTUS)
    Call<AboutUsResult> about_us_data(@Field("func") String about_us, @Field("organization_id") String organization_id);


    @FormUrlEncoded
    @POST(AppConstant.ENDPOINT.HOMESCREEN)
    Call<HomeScreenResponse> home_screen_data(@Field("user_id") String userid);

    @FormUrlEncoded
    @POST(AppConstant.ENDPOINT.CHANGEPASSWORD)
    Call<ChangePasswordResponse> change_password(@Field("func") String func, @Field("user_id") String user_id, @Field("old_password") String old_password, @Field("new_password") String new_password);

    @FormUrlEncoded
    @POST(AppConstant.ENDPOINT.ALLTRUCKDETAILS)
    Call<AllTruckResponse> all_truck_details_list(@Field("user_id") String userid);

    /*@FormUrlEncoded
    @POST(AppConstant.ENDPOINT.ALLTRUCKDETAILS)
    Call<AllTruckResponse> all_truck_details_list11(@Field("user_id") String userid);*/

    @FormUrlEncoded
    @POST(AppConstant.ENDPOINT.LOGOUT)
    Call<ChangePasswordResponse> user_logout(@Field("user_id") String userid);

    @FormUrlEncoded
    @POST(AppConstant.ENDPOINT.HELP_SUPPORT)
    Call<HelpAndSupportResponse> help_and_support(@Field("user_id") String userid);

    @FormUrlEncoded
    @POST(AppConstant.ENDPOINT.USER_DASHBOARD_NEW)
    Call<DashboardNewResponse> user_dashboard_new(@Field("user_id") String userid);

    @FormUrlEncoded
    @POST(AppConstant.ENDPOINT.NOTIFICATION)
    Call<DashboardNewResponse> user_notification(@Field("notification") String notification,@Field("sound") String sound,@Field("vibrate") String vibrate);

    @FormUrlEncoded
    @POST(AppConstant.ENDPOINT.PLAYBACK_MAP)
    Call<DashboardNewResponse> playback_map(@Field("imei") String imei);


}
