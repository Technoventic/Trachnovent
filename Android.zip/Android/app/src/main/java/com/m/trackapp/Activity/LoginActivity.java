package com.m.trackapp.Activity;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.m.trackapp.R;
import com.m.trackapp.RetrofitClasses.ApiClient;
import com.m.trackapp.RetrofitClasses.MyApiEndpointInterface;
import com.m.trackapp.Utility.AppPreferences;
import com.m.trackapp.model.LoginRequest;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.m.trackapp.Activity.DashboardActivity.PREFS_NAME;

public class LoginActivity extends Activity implements View.OnClickListener {

    private String username,password;
    private Button ok;
    private EditText editTextUsername,editTextPassword;
    private CheckBox saveLoginCheckBox;
    TextView tvForgotPassword;
    private SharedPreferences loginPreferences;
    private SharedPreferences.Editor loginPrefsEditor;
    private Boolean saveLogin;
    private String isRemember = "0";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
//Get "hasLoggedIn" value. If the value doesn't exist yet false is returned
        boolean hasLoggedIn = settings.getBoolean("hasLoggedIn", false);

        if(hasLoggedIn)
        {
            //Go directly to main activity.
            startActivity(new Intent(LoginActivity.this,DashboardActivity.class));
        }
/*
        if(AppPreferences.getStringPrefuserpw(this).equalsIgnoreCase("HOME")){
            startActivity(new Intent(LoginActivity.this,DashboardActivity.class));
        }
*/

        setContentView(R.layout.activity_login);

        ok = (Button)findViewById(R.id.btnLogin);
        ok.setOnClickListener(this);
        editTextUsername = (EditText)findViewById(R.id.etEmailid);
        editTextPassword = (EditText)findViewById(R.id.etPassword);
        saveLoginCheckBox = (CheckBox)findViewById(R.id.rememberme);
        tvForgotPassword =  (TextView)findViewById(R.id.forgotPassword);
        loginPreferences = getSharedPreferences("loginPrefs", MODE_PRIVATE);
        loginPrefsEditor = loginPreferences.edit();

        saveLogin = loginPreferences.getBoolean("saveLogin", false);
        if (saveLogin == true) {
            isRemember ="1";
            editTextUsername.setText(loginPreferences.getString("username", ""));
            editTextPassword.setText(loginPreferences.getString("password", ""));
            saveLoginCheckBox.setChecked(true);
        }
        tvForgotPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity.this,ForgotPassword.class));
            }
        });
    }

    public void onClick(View view) {
        if (view == ok) {
            /*InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(editTextUsername.getWindowToken(), 0);*/

            username = editTextUsername.getText().toString();
            password = editTextPassword.getText().toString();

            if (saveLoginCheckBox.isChecked()) {
                loginPrefsEditor.putBoolean("saveLogin", true);
                loginPrefsEditor.putString("username", username);
                loginPrefsEditor.putString("password", password);
                loginPrefsEditor.commit();
            } else {
                loginPrefsEditor.clear();
                loginPrefsEditor.commit();
            }

            doSomethingElse();
        }
    }

    public void doSomethingElse() {
       /* startActivity(new Intent(LoginActivity555.this, ForgotPassword.class));
        LoginActivity555.this.finish();*/
        String data1 = editTextUsername.getText().toString().trim();
        String data2 = editTextPassword.getText().toString().trim();
        boolean invalid = false;

        if(data1.equals("")){
            invalid = true;
            Toast.makeText(getApplicationContext(), "Email ID Missing", Toast.LENGTH_SHORT).show();
        }else if(data2.equals("")){
            invalid = true;
            Toast.makeText(getApplicationContext(), "Password Missing", Toast.LENGTH_SHORT).show();
        }
        if(invalid == false){
            getData();
        }
    }

    private void getData() {
        //  final   Gson gson = new Gson();
        MyApiEndpointInterface apiService = ApiClient.getClient().create(MyApiEndpointInterface.class);
        Call<LoginRequest> call = apiService.getLoginDetail(editTextUsername.getText().toString(),editTextPassword.getText().toString(),isRemember);
        call.enqueue(new Callback<LoginRequest>() {
            @Override
            public void onResponse(Call<LoginRequest> call, Response<LoginRequest> response) {

                try {

                    Log.d("LOGINRESPONSE",response.body().toString());
                    LoginRequest loginResult =  response.body();
                   // AppPreferences dataProccessor = new AppPreferences(LoginActivity.this);
                    AppPreferences appPreferences = new AppPreferences(LoginActivity.this);
                    appPreferences.setStrUserId("userid",loginResult.getResult().getUserId());
                    //AppPreferences.setStringPrefuserid(LoginActivity.this,loginResult.getResult().getUserId());


                    if(loginResult.getStatus().equalsIgnoreCase("200")){
                        startActivity(new Intent(LoginActivity.this,DashboardActivity.class));

                        editTextUsername.setText("");
                        editTextPassword.setText("");
                        LoginActivity.this.finish();
                        //  finish();
                    }
                    else if(loginResult.getStatus().equalsIgnoreCase("400")){
                        Toast.makeText(LoginActivity.this, "email id or password not matched", Toast.LENGTH_SHORT).show();
                    }






                } catch (Exception e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Call<LoginRequest> call, Throwable t) {
                Log.d("SSSSS33",t.toString());
            }
        });
/*
        call.enqueue(new Callback<List<LoginResult>>() {
            @Override
            public void onResponse(Call<List<LoginResult>> call, Response<List<LoginResult>> response) {
                Log.d("WWWWW",response.body().toString());



            }

            @Override
            public void onFailure(Call<List<LoginResult>> call, Throwable t) {
                Log.e("MainActivity", t.toString());
                //    progressDoalog.dismiss();
            }
        });
*/


    }
}
