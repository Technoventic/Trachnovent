package com.m.trackapp.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class Stop1 {


    @SerializedName("imei")
    @Expose
    private List<Imei_> imei = null;

    public List<Imei_> getImei() {
        return imei;
    }

    public void setImei(List<Imei_> imei) {
        this.imei = imei;
    }
}
