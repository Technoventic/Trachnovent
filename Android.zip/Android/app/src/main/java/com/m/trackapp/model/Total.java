package com.m.trackapp.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class Total {
    @SerializedName("imei")
    @Expose
    private List<Imei_____> imei = null;

    public List<Imei_____> getImei() {
        return imei;
    }

    public void setImei(List<Imei_____> imei) {
        this.imei = imei;
    }}
