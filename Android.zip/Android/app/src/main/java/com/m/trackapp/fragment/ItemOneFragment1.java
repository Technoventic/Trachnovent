package com.m.trackapp.fragment;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.m.trackapp.R;
import com.m.trackapp.RetrofitClasses.ApiClient;
import com.m.trackapp.RetrofitClasses.MyApiEndpointInterface;
import com.m.trackapp.Utility.AppPreferences;
import com.m.trackapp.Utility.FontAwesome;
import com.m.trackapp.model.DashboardResponse;
import com.m.trackapp.model.HomeScreenResponse;
import com.m.trackapp.model.HomeScreenResult;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class ItemOneFragment1 extends Fragment implements OnMapReadyCallback,LocationListener,GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener  {

    private GoogleMap mMap;
    Location l;
    LocationManager lm;
    LocationListener ll;
    LatLng pos;
    FontAwesome threedots_img,btnplus,btnminus;
    PopupWindow pw;
    RecyclerView mRecyclerView;
    TextView textView1,textView2,textView3,textView4,textView5,textView6;
    List<HomeScreenResult> listItems = new ArrayList<HomeScreenResult>();


    public ItemOneFragment1() {
        // Required empty public constructor
    }
    public static ItemOneFragment1 newInstance() {
        ItemOneFragment1 fragment = new ItemOneFragment1();
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
       final View rootview = inflater.inflate(R.layout.fragment_item_one, container, false);
       init(rootview);

       // mRecyclerView = rootview.findViewById(R.id.recyclerview);
        getDashboardData();
        getAllTruckData();
        //GridLayoutManager mGridLayoutManager = new GridLayoutManager(getActivity(), 2);
     /*   //RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false));
      //  mRecyclerView.setLayoutManager(mLayoutManager);
        SettingAdapter myAdapter = new SettingAdapter(getActivity(),dashboardResponses);
        mRecyclerView.setAdapter(myAdapter);*/

      threedots_img =  (FontAwesome)rootview.findViewById(R.id.btn2);
        btnplus =  (FontAwesome)rootview.findViewById(R.id.btnplus);
        btnminus =  (FontAwesome)rootview.findViewById(R.id.btnminus);
        threedots_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              //  showPopup(v);
                initiatePopupWindow(rootview);
            }
        });


       return  rootview;
    }

    private void getAllTruckData() {
        MyApiEndpointInterface apiService = ApiClient.getClient().create(MyApiEndpointInterface.class);

        Call<HomeScreenResponse> call = apiService.home_screen_data(AppPreferences.getStrUserId("userid"));//userid from appprefrence
        call.enqueue(new Callback<HomeScreenResponse>() {
            @Override
            public void onResponse(Call<HomeScreenResponse> call, Response<HomeScreenResponse> response) {

                // AboutUsResult aboutUsResult = response.body();
                //Log.d("FFF",aboutUsResult.toString());

                try {
                    HomeScreenResponse homeScreenResponse = response.body();
                    // DashboardResponse dashboardResponse = response.body();

                    if(homeScreenResponse.getStatus().equalsIgnoreCase("200")){
                        listItems.add(homeScreenResponse.getResult());

                        Log.d("RESULTTT",homeScreenResponse.getResult().getStop().size()+"");

                    }
                    else if(homeScreenResponse.getStatus().equalsIgnoreCase("400")){
                        Toast.makeText(getActivity(),homeScreenResponse.getMessage(), Toast.LENGTH_SHORT).show();
                    }






                } catch (Exception e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Call<HomeScreenResponse> call, Throwable t) {
                Log.d("SSSSS33",t.toString());
            }
        });

    }

    private void init(View rootview) {
     textView1 =  (TextView)rootview.findViewById(R.id.text1);
     textView2 =  (TextView)rootview.findViewById(R.id.text2);
     textView3 =  (TextView)rootview.findViewById(R.id.text3);
     textView4 =  (TextView)rootview.findViewById(R.id.text4);
     textView5 =  (TextView)rootview.findViewById(R.id.text5);
     textView6 =  (TextView)rootview.findViewById(R.id.text6);
    }

    private void getDashboardData() {
        MyApiEndpointInterface apiService = ApiClient.getClient().create(MyApiEndpointInterface.class);

        Call<DashboardResponse> call = apiService.dashboard_data(AppPreferences.getStrUserId("userid"));//userid from appprefrence
        call.enqueue(new Callback<DashboardResponse>() {
            @Override
            public void onResponse(Call<DashboardResponse> call, Response<DashboardResponse> response) {

                try {

                    DashboardResponse dashboardResponse = response.body();

                    if(dashboardResponse.getStatus().equalsIgnoreCase("200")){
                        Log.d("RUNNINGCONDITION",dashboardResponse.getResult().getRunning()+"");
textView1.setText(dashboardResponse.getResult().getTotal()+""); //all
textView2.setText(dashboardResponse.getResult().getRunning()+"");
textView3.setText(dashboardResponse.getResult().getIdle()+"");
textView4.setText(dashboardResponse.getResult().getStop()+"");
textView5.setText(dashboardResponse.getResult().getOffline()+""); //inactive
textView6.setText(dashboardResponse.getResult().getNoData()+"");
                        //RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
                     /*   mRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false));
                        //  mRecyclerView.setLayoutManager(mLayoutManager);
                        SettingAdapter myAdapter = new SettingAdapter(getActivity());
                        mRecyclerView.setAdapter(myAdapter);*/

                    }
                    else if(dashboardResponse.getStatus().equalsIgnoreCase("400")){
                        Toast.makeText(getActivity(),dashboardResponse.getMessage(), Toast.LENGTH_SHORT).show();
                    }







                } catch (Exception e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Call<DashboardResponse> call, Throwable t) {
                Log.d("SSSSS33",t.toString());
            }
        });
    }

    private void initiatePopupWindow(View rootview) {
        try {
            List<String>items =new ArrayList<String>();
            items.add("Satelite");
            items.add("Normal");
            items.add("Hybrid");
            items.add("Terrain");


            LayoutInflater inflater = (LayoutInflater) getActivity()
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

            View layout = inflater.inflate(R.layout.custom_popup,
                    (ViewGroup)rootview.findViewById(R.id.popup_element));

            pw = new PopupWindow(layout, 320, 420, true);
            pw.showAtLocation(layout, Gravity.CENTER, 0, 0);


            ListView listView = (ListView) layout.findViewById(R.id.listview);

            ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>
                    (getActivity(), android.R.layout.simple_list_item_1, items){
                @Override
                public View getView(int position, View convertView, ViewGroup parent){

                    View view = super.getView(position, convertView, parent);
                    TextView tv = (TextView) view.findViewById(android.R.id.text1);
                    tv.setTextColor(Color.WHITE);
                    return view;
                }
            };

            // DataBind ListView with items from ArrayAdapter
            listView.setAdapter(arrayAdapter);
            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view,
                                        int position, long id) {

                    Toast.makeText(getActivity(),
                            "Click ListItem Number " + position, Toast.LENGTH_LONG)
                            .show();
                    pw.dismiss();
                }
            });

           /* ArrayAdapter<String> itemsAdapter =
                    new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, items);

            listView.setAdapter(itemsAdapter);
            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view,
                                        int position, long id) {
                  *//*  Toast.makeText(getActivity(),
                            "Click ListItem Number " + position, Toast.LENGTH_LONG)
                            .show();*//*
                    pw.dismiss();
                }
            });*/

            /*Button cancelButton = (Button) layout.findViewById(R.id.end_data_send_button);
            cancelButton.setOnClickListener(cancel_button_click_listener);*/

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
/*
    private View.OnClickListener cancel_button_click_listener = new View.OnClickListener() {
        public void onClick(View v) {
            pw.dismiss();
        }
    };
*/

/*
    private void showPopup(View v) {
        PopupMenu popup = new PopupMenu(getActivity(), v);
        MenuInflater inflater = popup.getMenuInflater();
        inflater.inflate(R.menu.menu_popup, popup.getMenu());
        popup.show();
    }
*/

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        lm = (LocationManager) getActivity().getSystemService(Context.LOCATION_SERVICE);
        ll = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {
                l = (Location) location;
            }

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {}

            @Override
            public void onProviderEnabled(String provider) {}

            @Override
            public void onProviderDisabled(String provider) {}
        };
        if(getActivity()!=null) {
            SupportMapFragment mapFragment = (SupportMapFragment) getActivity().getSupportFragmentManager()
                    .findFragmentById(R.id.map);
            if (mapFragment != null) {
                mapFragment.getMapAsync(this);
            }
        }
    }
/*
    @Override
    public void onMapReady(final GoogleMap googleMap) {
        mMap = googleMap;
        if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        googleMap.setMyLocationEnabled(true);
        googleMap.getUiSettings().setZoomControlsEnabled(true);

        mMap.setOnMapLoadedCallback(new GoogleMap.OnMapLoadedCallback() {
            @Override
            public void onMapLoaded() {
                for (final HomeScreenResult listItem : listItems) {
                    Log.e(TAG, "onMapLoaded: listItem >> " + listItem);
                    for(in)
                    if (listItem.getStop().get().getLattitude() != null && !listItem.getLatitude().equalsIgnoreCase("") && listItem.getLongitude() != null && !listItem.getLongitude().equalsIgnoreCase("")) {
                        final String latatitude = listItem.getLatitude();
                        final String longtitude = listItem.getLongitude();
                        String name = "", address = "", contact = "";
                        name = listItem.getBusinessName();
                        address = listItem.getBusinessAddress();
                        contact = listItem.getBusinessContactNo();
                        LatLng latLng = new LatLng(Double.parseDouble(latatitude), Double.parseDouble(longtitude));
                        MarkerOptions markerOpt = new MarkerOptions();
                        markerOpt.position(latLng)
                                .title(name)
                                .snippet(address + "\nContact No. " + contact)
                                .icon(BitmapDescriptorFactory.fromResource(R.drawable.logo));

                        direction.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                              */
/*  String uri = String.format(Locale.ENGLISH, "geo:%f,%f", Float.parseFloat(latatitude), Float.parseFloat(longtitude));
                                String geoUri = "http://maps.google.com/maps?q=loc:" + Float.parseFloat(latatitude) + "," + Float.parseFloat(longtitude) + " (" + listItem.getBusinessName() + ")";
                                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(geoUri));
                                startActivity(intent);*//*


                                Intent intent = new Intent(android.content.Intent.ACTION_VIEW,
                                        Uri.parse("google.navigation:q=" + Float.parseFloat(latatitude)
                                                + "," + Float.parseFloat(longtitude)+ ""));

                                startActivity(intent);
                            }
                        });
                        adapter = new CustomInfoWindowAdapter(MapsActivity.this);
                        mMap.setInfoWindowAdapter(adapter);
                        if (listItems.size() == 1) {
                            mMap.addMarker(markerOpt).showInfoWindow();
                            mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(Double.parseDouble(latatitude), Double.parseDouble(longtitude)), 15));
                            direction.setVisibility(View.VISIBLE);
                        } else if (listItems.size() > 1)
                            mMap.addMarker(markerOpt);


                       */
/* CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(latLng, 13);
                        mMap.animateCamera(cameraUpdate);*//*

                    }
                    dismissProgressDialog();
                }
            }
        });


    }
*/

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);


/* btnplus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mMap.animateCamera(CameraUpdateFactory.zoomIn());
            }
        });
        btnminus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mMap.animateCamera(CameraUpdateFactory.zoomOut());
            }
        });*//*


      */
    if(ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            lm.requestLocationUpdates(lm.NETWORK_PROVIDER, 0, 0, ll);
        }

        pos = new LatLng(l.getLatitude(), l.getLongitude());

        // Add a marker in Sydney and move the camera
        mMap.setMyLocationEnabled(true);
        mMap.addMarker(new MarkerOptions().position(pos).title("Marker in Sydney"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(pos));}
/*

    }
*/


    @Override
    public void onLocationChanged(Location location) {

    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {

    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }
}