package com.m.trackapp.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class Running {

    @SerializedName("imei")
    @Expose
    private List<Imei> imei = null;

    public List<Imei> getImei() {
        return imei;
    }

    public void setImei(List<Imei> imei) {
        this.imei = imei;
    }
}
