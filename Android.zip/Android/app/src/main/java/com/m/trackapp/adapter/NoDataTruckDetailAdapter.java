package com.m.trackapp.adapter;

import android.content.Context;
import android.location.Address;
import android.location.Geocoder;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.androidquery.AQuery;
import com.m.trackapp.R;
import com.m.trackapp.model.Imei_;
import com.m.trackapp.model.Imei___;

import java.io.IOException;
import java.util.List;
import java.util.Locale;


public class NoDataTruckDetailAdapter extends RecyclerView.Adapter<NoDataTruckDetailAdapter.ViewHolder  > {

    Context context;
    //List<List<Object>> noData;
    List<Imei___> imeiList;
    NoDataTruckDetailAdapter.OnItemClick onItemClick;




    public NoDataTruckDetailAdapter(Context context, List<Imei___> imeiList,NoDataTruckDetailAdapter.OnItemClick onItemClick){
        this.context = context;
        this.imeiList = imeiList;
        this.onItemClick = onItemClick;



    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.truck_detail_layout, parent, false);
        ViewHolder viewHolder = new ViewHolder(v);
        return viewHolder;
    }
    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        final Imei___ modal = imeiList.get(position);
        holder.tvTruck_no.setText( imeiList.get(position).getName());

        holder.tvtruckSpeed.setText( imeiList.get(position).getSpeed()+" Km/h");
        holder.tvTruckTime.setText( imeiList.get(position).getDateServer());
        if(!modal.getImg().equalsIgnoreCase("")){
            new AQuery(context).id(holder.imgTruck).image(modal.getImg(), true, true, 0, 0);

        }

        //For Location(Address)

        double latitude = Double.parseDouble(imeiList.get(position).getLattitude());
        double  longitude = Double.parseDouble(imeiList.get(position).getLongitude());

        Geocoder geocoder;
        List<Address> addresses;
        geocoder = new Geocoder(context, Locale.getDefault());

        try {
            addresses = geocoder.getFromLocation(latitude, longitude, 1); // Here 1 represent max location result to returned, by documents it recommended 1 to 5

            if (addresses != null && addresses.size() > 0) {

                if (addresses.get(0).getAddressLine(0) != null) {

                    String  address = addresses.get(0).getAddressLine(0) + " ";
                    holder.tvtrucklocation.setText(address);
                }
            }

               /* String address = addresses.get(0).getAddressLine(0); // If any additional address line present than only, check with max available address lines by getMaxAddressLineIndex()
            Log.d("FFFFF",address);
            String city = addresses.get(0).getLocality();
            holder.tvtrucklocation.setText(address);*/
           /* String state = addresses.get(0).getAdminArea();
            String country = addresses.get(0).getCountryName();
            String postalCode = addresses.get(0).getPostalCode();
            String knownName = addresses.get(0).getFeatureName(); // Only if available else return NULL*/
        } catch (IOException e) {
            e.printStackTrace();
        }

        holder.view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onItemClick.itemClick(modal);
            }
        });


    }

    @Override
    public int getItemCount() {
        return imeiList.size() ;
    }
    public class ViewHolder extends RecyclerView.ViewHolder  {
        TextView tvTruck_no,tvtrucklocation,tvtruckSpeed,tvTruckTime;
        //  CustomTextView order_id,order_amount,order_time,order_status;
        View view;
        ImageView imgTruck;

        public ViewHolder(View itemView) {
            super(itemView);
            view=itemView;
            tvTruck_no = (TextView)itemView.findViewById(R.id.tvtruckno);
            tvtrucklocation = (TextView)itemView.findViewById(R.id.tvtrucklocation);
            tvtruckSpeed = (TextView)itemView.findViewById(R.id.tvtruckSpeed);
            tvTruckTime = (TextView)itemView.findViewById(R.id.tvTruckTime);
            imgTruck = (ImageView)itemView.findViewById(R.id.imgtruck);

        }

    }

    public  interface OnItemClick{
        void itemClick(Imei___ imeimoidal);
    }


}