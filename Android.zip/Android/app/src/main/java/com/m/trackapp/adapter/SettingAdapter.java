package com.m.trackapp.adapter;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


import com.m.trackapp.R;
import com.m.trackapp.Utility.FontAwesome;
import com.m.trackapp.fragment.ChangePasswordFragment;
import com.m.trackapp.fragment.TruckDetailFragment;
import com.m.trackapp.model.DashboardResult;

import java.util.List;


public class SettingAdapter extends RecyclerView.Adapter<SettingAdapter.ViewHolder  > {

    Context context;
    GradientDrawable gd;



    public SettingAdapter(Context context){
        this.context = context;



    }

    @Override
    public SettingAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.map_item_recycler, parent, false);
        SettingAdapter.ViewHolder viewHolder = new SettingAdapter.ViewHolder(v);
         gd = new GradientDrawable();
         gd.setShape(GradientDrawable.RECTANGLE);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        if (position == 0) {

            /*GradientDrawable gd = new GradientDrawable();
            gd.setShape(GradientDrawable.RECTANGLE);*/
            gd.setColor(context.getResources().getColor(R.color.darkblu)); // make the background transparent
            gd.setStroke(2, context.getResources().getColor(R.color.darkblu));
            gd.setCornerRadius(15.0f); // border corner radius
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                holder.textview.setBackground(gd);
            }
        }
    else if(position == 1) {
            gd.setColor(context.getResources().getColor(R.color.green)); // make the background transparent
            gd.setStroke(2, context.getResources().getColor(R.color.green));
            gd.setCornerRadius(15.0f); // border corner radius
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                holder.textview.setBackground(gd);
            }
    }
    else if(position == 2) {
            gd.setColor(context.getResources().getColor(R.color.yellow)); // make the background transparent
            gd.setStroke(2, context.getResources().getColor(R.color.yellow));
            gd.setCornerRadius(15.0f); // border corner radius
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                holder.textview.setBackground(gd);
            }
    }
    else if(position == 3) {
            gd.setColor(context.getResources().getColor(R.color.red)); // make the background transparent
            gd.setStroke(2, context.getResources().getColor(R.color.red));
            gd.setCornerRadius(15.0f); // border corner radius
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                holder.textview.setBackground(gd);
            }
    }
    else if(position == 4) {
            gd.setColor(context.getResources().getColor(R.color.light_blu)); // make the background transparent
            gd.setStroke(2, context.getResources().getColor(R.color.light_blu));
            gd.setCornerRadius(15.0f); // border corner radius
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                holder.textview.setBackground(gd);
            }
    }
    else if(position == 5) {
            gd.setColor(context.getResources().getColor(R.color.gray)); // make the background transparent
            gd.setStroke(2, context.getResources().getColor(R.color.gray));
            gd.setCornerRadius(15.0f); // border corner radius
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                holder.textview.setBackground(gd);
            }
    }
    holder.itemView.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            FragmentTransaction transaction = ((FragmentActivity)context).getSupportFragmentManager()
                    .beginTransaction();
            transaction.replace(R.id.frame_layout, TruckDetailFragment.newInstance());
            transaction.addToBackStack(null);
            transaction.commit();
        }
    });

        //holder.tvbtn1.setTypeface(FontManager.getTypeface(FontManager.FONTAWESOME.));
     /*   Typeface iconFont = FontManager.getTypeface(context, FontManager.FONTAWESOME);
        FontManager.markAsIconContainer(holder.tvbtn1, iconFont);*/

       /* Typeface font = Typeface.createFromAsset(context.getAssets(), "fontawesome3.ttf");
        holder.tvbtn1.setTypeface(font);*/
}

    @Override
    public int getItemCount() {
        return 6 ;
    }
    public class ViewHolder extends RecyclerView.ViewHolder  {
        TextView textview;

        //  CustomTextView order_id,order_amount,order_time,order_status;
        View view;

        public ViewHolder(View itemView) {
            super(itemView);
            view=itemView;

            textview =(TextView)view.findViewById(R.id.textview);


        }

    }



}